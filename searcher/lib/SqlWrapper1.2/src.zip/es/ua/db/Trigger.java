/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * An abstract class which represents a SQL trigger which detect some
 * table actions (INSERT, UPDATE or DELETE) and throw events when that acctions occurs. 
 * This class need database permisions for creating trigger and, depend on the implementation,
 * aslo  tables.
 * This class must be adapted to each database manager using a subclass.
 * <p>Example of use:</p>
 * <pre>
 * // Create the database connection
 * Database database = new MySQLDatabase("localhost", "user_name", "user_pass", "database_name");
 * // Create  the trigger watching the table t1
 * MySQLTrigger triggerInsert = database.createTrigger("t1", Trigger.ActionTime.AFTER, Trigger.ActionOperation.INSERT);
 * MySQLTrigger triggerUpdate = database.createTrigger("t1", Trigger.ActionTime.AFTER, Trigger.ActionOperation.UPDATE);
 * MySQLTrigger triggerDelete = database.createTrigger("t1", Trigger.ActionTime.AFTER, Trigger.ActionOperation.DELETE);
 * try {
 *      // Add the event listener
 *      TriggerListener listener = new MyTriggerListener();
 *      trigger.addTriggerListener(listener);
 *      ...
 * } finally {
 *      // When you finish your application you have to close the triggers and database connection
 *      triggerInsert.close();
 *      triggerDelete.close();
 *      triggerUpdate.close();
 *      database.close();
 * }
 * </pre>
 * <p>The object listener have to implements the TriggerListener interface. For example:</p> 
 * <pre>
 * class MyTriggerListener implements TriggerListener {

    public void insertEvent(Iterator<Row> addRows, Table table, Trigger.ActionTime time) throws Throwable {
        System.out.println("Inserted rows with the following values:");
        while(addRows.hasNext()) {
            Row row = addRows.next();
            System.out.println("a: " + row.getField("a"));
            System.out.println("b: " + row.getField("b"));
        }
    }

    public void updateEvent(Iterator<Row> oldRows, Iterator<Row> newRows, Table table, Trigger.ActionTime time) throws Throwable {
        System.out.println("Update rows with the following values:");
        while(oldRows.hasNext()) {
            Row row = oldRows.next();
            System.out.println("a: " + row.getField("a"));
            System.out.println("b: " + row.getField("b"));
        }
        System.out.println("by rows with the following values:");
        while(newRows.hasNext()) {
            Row row = newRows.next();
            System.out.println("a: " + row.getField("a"));
            System.out.println("b: " + row.getField("b"));
        }
    }

    public void deleteEvent(Iterator<Row> deletedRows, Table table, Trigger.ActionTime time) throws Throwable {
        System.out.println("Borrando registros:");
        while(deletedRows.hasNext()) {
            Row row = deletedRows.next();
            System.out.println("a: " + row.getField("c"));
            System.out.println("b: " + row.getField("b"));
        }
    }

    public void errorEvent(Throwable ex, Table table, Trigger.ActionTime time) throws Throwable {
       System.err.println("Ha habido un error:" + ex.getMessage());
       // if you want to stop the trigger and close it properly you only need to do throw an exception:
       // throw ex;
    }
}
 * </pre>
 *
 * @see Database
 * @see TriggerListener
 * @author Jos&eacute; M. G&oacute;mez;
 */
abstract public class Trigger implements Closeable, Runnable, AutoCloseable {
    /**
     * When the event is thrown, before or after the operation.
     */
    public enum ActionTime {
        BEFORE,
        AFTER
    }

    /**
     * Operation which will throw the event.
     */
    public enum ActionOperation {
        INSERT,
        DELETE,
        UPDATE
    }
    /** 
     * A new connection to the database which is based on the constructor one.
     */
    protected final Database database;
    /**
     * The table to listen the events.
     */
    protected final Table table;
    /**
     * When the event is thrown, before or after the operation.
     */
    protected final ActionTime time;
    /**
     * Operation which will throw the event.
     */
    protected final ActionOperation operation;
    /** 
     * The list of listener to fire the event.
     */
    private final List<TriggerListener> listeners = new ArrayList<TriggerListener>();
    /**
     * The thread which are waiting for events.
     */
    protected final Thread thread;
    /**
     * If retrieve inserted, updated or deleted rows or not.
     */
    protected final boolean retrieveRows;
    /**
     * Constructor.
     * @param database the database connection. This connection is not directly 
     * used but one or more new connections are created based on this connection data.
     * @param table the table to listen the events.
     * @param time when the event is thrown, before or after the operation.
     * @param operation operation which will throw the event.
     * @param retrieveRows if retrieve inserted, updated or deleted rows or not
     * @throws DatabaseException if any database exception occurs.
     */
    Trigger(Database database, Table table, ActionTime time, ActionOperation operation, boolean retrieveRows) throws DatabaseException {
        this.database = database.newInstance();
        this.table = table;
        this.time = time;
        this.operation = operation;
        this.retrieveRows = retrieveRows;
        thread = new Thread(this);
    }
    
    /**
     * Obtain a string representation of the action time.
     * @param time the time constant.
     * @return A string which represents the name of the action time.
     */
    protected String getTimeString(ActionTime time) {
        switch(time) {
            case BEFORE: return "BEFORE";
            case AFTER: return "AFTER";
        }
        return "BEFORE";
    }

    /**
     * Obtain a string representation of the operation action.
     * @param operation the operation constant.
     * @return A string which represents the name of the operation action.
     */
    protected String getOperationString(ActionOperation operation) {
        switch(operation) {
            case INSERT: return "INSERT";
            case DELETE: return "DELETE";
            case UPDATE: return "UPDATE";
        }
        return "INSERT";
    }
    
    /**
     * Execute the event insert in all listeners.
     * @param insertedRows the list of inserted rows.
     * @throws Throwable if any exception occurs dealing with this event.
     */
    protected final void fireInsertEvent(Iterator<Row> insertedRows) throws Throwable {
        for(TriggerListener listener : listeners) {
            listener.insertEvent(insertedRows, table, time);
        }
    }
    
    /**
     * Execute the event delete in all listeners.
     * @param deletedRows the list of deleted rows.
     * @throws Throwable if any exception occurs dealing with this event.
     */
    protected void fireDeleteEvent(Iterator<Row> deletedRows) throws Throwable {
        for(TriggerListener listener : listeners) {
            listener.deleteEvent(deletedRows, table, time);
        }
    }

    /**
     * Execute the event insert in all listeners.
     * @param oldRows the list of rows with the old values before the update.
     * @param newRows the list of rows with the new values after the update.
     * @throws Throwable if any exception occurs dealing with this event.
     */
    protected void fireUpdateEvent(Iterator<Row> oldRows, Iterator<Row> newRows) throws Throwable {
        for(TriggerListener listener : listeners) {
            listener.updateEvent(oldRows, newRows, table, time);
        }
    }
    
    /**
     * Execute all listener which are listening this event.
     * @param ex the thrown exception which caused this error event.
     * @exception Throwable if any exception occurs. This exception will stop
     * the trigger.
     */
    protected void fireErrorEvent(Throwable ex) throws Throwable {
        for(TriggerListener listener : listeners) {
            listener.errorEvent(ex, table, time);
        }
    }
    
    /**
     * Add a listener to this trigger.
     * @param listener the listener to add.
     */
    public void addTriggerListener(TriggerListener listener) {
        if(!thread.isAlive()) {
            thread.start();
        }
        listeners.add(listener);
    }
}
