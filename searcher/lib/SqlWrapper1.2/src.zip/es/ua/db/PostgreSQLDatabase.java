/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author Jos&eacute; M. G&oacute;mez;
 */
public class PostgreSQLDatabase extends RemoteDatabase {

    /**
     * The jdbc driver for PostgreSQL.
     */
    static public final String DRIVER = "org.postgresql.Driver";
    /**
     * The protocol for MySQL.
     */
    static public final String PROTOCOL = "jdbc:postgresql://";

    /**
     * Create a conexión with the database.
     *
     * @param host the database server host.
     * @param user the user to connect with the database.
     * @param password the user password to connect with the database.
     * @param databaseName the database name.
     * @throws DatabaseException if a database access error occurs or the
     * JDBC driver is not in the classpath.
     */
    public PostgreSQLDatabase(String host, String user, String password, String databaseName) throws DatabaseException {
        this(host, null, user, password, databaseName);
    }

    /**
     * Create a conexión with the database.
     *
     * @param host the database server host.
     * @param port the port used to connect with PostgreSQL.
     * @param user the user to connect with the database.
     * @param password the user password to connect with the database.
     * @param databaseName the database name.
     * @throws DatabaseException if a database access error occurs or the
     * JDBC driver is not in the classpath.
     */
    public PostgreSQLDatabase(String host, Integer port, String user, String password, String databaseName) throws DatabaseException {
        super(DRIVER, getURL(host, port, user, password, databaseName), host, port, user, password, databaseName);
    }

    /**
     * Obtain a database connection without create a Database instance.
     *
     * @param host the database server host.
     * @param port the database server port. If this argument is null, then the
     * default value is used.
     * @param databaseName the database name. If this argument is null, then
     * return a conexion with the PostgreSql server.
     * @param user the user to connect
     * @param password the password for that user
     * @return the database connexion
     * @throws ClassNotFoundException if the jdbc library for mysql was not
     * included in the project
     * @throws SQLException if a database access error occurs
     */
    static public Connection createConnection(String host, Integer port, String databaseName, String user, String password) throws ClassNotFoundException, SQLException {
        return createConnection(DRIVER, getURL(host, port, user, password, databaseName));
    }

    /**
     * Build the URL connection from the connection data.
     * @param host the database server host.
     * @param port the database server port. If this argument is null, then the default value is used.
	 * @param databaseName the database name. If this argument is null, then return a conexion with the MySql server.
     * @return a string witch represents the connection URL.
     * TODO: comprobar que es necesario user y password.
     */
    private static String getURL(String host, Integer port, String user, String password, String databaseName) {
        return PROTOCOL + host + ((port != null) ? ":" + port : "") + ((databaseName != null) ? "/" + databaseName : "") + "?user=" + user + "&password=" + password;
    }
    

    /**
     * Obtain a database server connection without neither create a Database
     * instance nor connect with a specific database.
     *
     * @param host the database server host.
     * @param port the database server port. If this argument is null, then the
     * default value is used.
     * @param user the user to connect
     * @param password the password for that user
     * @return the database connexion
     * @throws ClassNotFoundException if the jdbc library for mysql was not
     * included in the project
     * @throws SQLException if a database access error occurs
     */
    static public Connection createConnection(String host, Integer port, String user, String password) throws ClassNotFoundException, SQLException {
        return createConnection(host, port, null, user, password);
    }

    @Override
    public String getDriver() {
        return DRIVER;
    }

    @Override
    public Database newInstance() throws DatabaseException {
        return new PostgreSQLDatabase(getHost(), getPort(), getUser(), getPassword(), getName());
    }
}
