/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.ua.db;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author jmgomez
 */
public class SQLExecutor {

    private final Statement statement;
    private final BufferedReader br;
    private final StringBuilder sb = new StringBuilder();
    private final long size;
    private long position;

    public SQLExecutor(File file, Connection connection) throws SQLException, FileNotFoundException {
        // Create a statement
        statement = connection.createStatement();
        // Open the file and calculate its size
        size = file.length();
        br = new BufferedReader(new FileReader(file));
    }
    
    public SQLExecutor(Reader reader, Connection connection) throws SQLException, FileNotFoundException {
        // Create a statement
        statement = connection.createStatement();
        // Open the file and calculate its size
        size = 0;
        br = new BufferedReader(reader);
    }
    
    public SQLExecutor(InputStream is, Connection connection) throws SQLException, FileNotFoundException {
        // Create a statement
        statement = connection.createStatement();
        // Open the file and calculate its size
        size = 0;
        br = new BufferedReader(new InputStreamReader(is));
    }
    
    public SQLExecutor(InputStream is, String encoding, Connection connection) throws SQLException, FileNotFoundException, UnsupportedEncodingException {
        // Create a statement
        statement = connection.createStatement();
        // Open the file and calculate its size
        size = 0;
        br = new BufferedReader(new InputStreamReader(is, encoding));
    }

    public SQLExecutor(String sql, Connection connection) throws SQLException, FileNotFoundException {
        statement = connection.createStatement();
        // Open the file
        size = sql.length();
        br = new BufferedReader(new StringReader(sql));
    }

    public void execute() throws SQLException, IOException {
        boolean comment = false;
        // Read the file
        while (br.ready()) {
            String line = br.readLine();
            position += line.length() + 1;
//            if (line.startsWith("/*")) {
//                comment = true;
//            }
            if(!comment) {
                // If the line is not a comment or empty line append it
                if (!line.startsWith("--") && !line.matches("^ *$")) {
                    sb.append(line);
                    sb.append('\n');
                }
            }
//            if (line.contains("*/")) {
//                comment = false;
//            }
            
        }
        // Execute all recollected statments
        if (sb.length() > 0) {
             String[] statements = sb.toString().split(";");
                for(String statement : statements) {
                    statement = statement.trim();
                    if(!statement.isEmpty()) {
                        //database.executeQuery(statement);
                        this.statement.execute(statement);
                    }
                }
//            statement.execute(sb.toString());
            sb.setLength(0);
        }
    }

    public long size() {
        return size;
    }

    public long position() {
        return position;
    }

    public void close() throws IOException, SQLException {
        br.close();
        statement.close();
    }

    @Override
    public void finalize() throws Throwable {
        super.finalize();
        close();
    }
}
