/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import static es.ua.db.DatabasePool.DatabasePoolAction.CLOSE;
import static es.ua.db.DatabasePool.DatabasePoolAction.GET;
import static es.ua.db.DatabasePool.DatabasePoolAction.RELEASE;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This class create a pool of database connections until a maximum of
 * connections. If this maximum is achieved, then the connections are shared
 * between processes in order to avoid that the same connection is used by two
 * different processes at the same time and synchronizing the access to read and write
 * in the database.
 * <p>This database pool is useful for control the access to several threads to the
 * same database using a maximum of connections (instead of creating a connection
 * for each thread). Another advantages are that only open once each connection and
 * ensure that all opened resources, like tables and queries, are properly colosed.</p>
 * <h2>Example of use</h2>
 * <p>In this example, a pool with a maximum of only 5 connections is created and their are used
 * by 100 different threads.</p>
 * <pre>
 * Database database = new MySQLDatabase(host, user, password, databaseName);
 * DatabasePool pool = new DatabasePool(database, 5);
 * ...
 * for(int i = 0; i < 100; i++) {
 *   new Thread() {
 *     public run() {
 *       while(true) {
 *         // do something
 *         ...
 *         Database database = pool.get(); // Obtain a free database connection
 *         try {
 *           // do something with the database
 *           ...
 *         } finally { // To asegure that release the database connection
 *           pool.release(database); // Release the database connection
 *         }
 *         // do something
 *         ...
 *       }
 *     }
 *   }.start();
 * }
 * </pre>
 * @author Javi Fern&aacute;ndez
 * @author Jos&eacute; M. G&oacute;mez;
 */
public class DatabasePool {
    /**
     * The database used in the constructor of this database pool. 
     * From this, the following connections will be created using the same
     * connection data that this one.
     */
    final private Database initialDatabase;
    /**
     * The maximum number of connections.
     */
    private final int maxConnections;
    /**
     * The list of available databases.
     */
    private final List<Database> available;
    /**
     * A set with all databases witch are being used.
     */
    private final Set<Database> used;

    /**
     * @return the maximum database connections to store in this pool.
     */
    public int getMaxConnections() {
        return maxConnections;
    }

    /** 
     * The different actions to do in this database pool. GET is to
     * obtain a new free database connection or wait is it is not free;
     * RELEASE is to release a database connection; and, CLOSE, is for close
     * all database connections.
     */
    static enum DatabasePoolAction { GET, RELEASE, CLOSE};
    
    /**
     * Create a database connection pool to allow only a maximum of connections 
     * with that database. It is necessary to open a initial database connection and
     * this class open the following ones as the connections are requesting to
     * the maximum connections. When this maximum is achieved, the following requests
     * are stopped until a connexions will free.
     * @param database The initial database connection.
     * @param maxConnections The maximum of database connections.
     */
    public DatabasePool(Database database, int maxConnections) {
        initialDatabase = database;
        this.maxConnections = maxConnections;
        available = new ArrayList<Database>(maxConnections);
        available.add(database);
        // The tabla hash must be a 1.33333... bigger than the number of elements to contain.
        used = new HashSet<Database>((int)Math.round(maxConnections / 0.75 + 0.5));
    }
    
    /**
     * Obtain a database connection from this pool. If there is already a 
     * released database connection, then return it; if there isn't a released database
     * and the number of connections don't achieve the maximum, then create a new one and
     * return it; finally, if there isn't a released database and the number of
     * connections has achieved the maximum, then wait for release one.
     * @return a released database connection.
     * @throws DatabaseException if a database access error occurs.
     */
    public Database get() throws DatabaseException {
        return sync(GET, null);
    }
    
    /**
     * Release a used database. When a database connection form this pool is
     * already used, this method must be called to indicate that this database
     * can be used for other process.
     * @param database The database to release.
     * @throws DatabaseException if a database access error occurs.
     */
    public void release(Database database) throws DatabaseException {
        sync(RELEASE, database);
    }
    
    /**
     * Close all databases of this pool. If there are databases being used
     * then, this method waits for its freedom.
     * @throws DatabaseException if a database access error occurs.
     */
    public void close() throws DatabaseException {
        sync(CLOSE, null);
    }
    
    /**
     * This method synchronizes the GET, RELEASE and CLOSE operations.
     * @param action The action to do.
     * @param database for the RELEASE action, the database to release, otherwise set to null.
     * @return for the GET action, return the next free database connection.
     * @throws DatabaseException if a database access error occurs.
     */
    private synchronized Database sync(DatabasePoolAction action, Database database) throws DatabaseException {
        switch(action) {
            case GET: {
                while(true) {
                    if(!available.isEmpty()) {
                        database = available.remove(0);
                        if(!database.isValid(10000)) {
                            database.close();
                            database = initialDatabase.newInstance();
                        }
                        used.add(database);
                        break;
                    }
                    else if(available.size() + used.size() < getMaxConnections()) {
                        database = initialDatabase.newInstance();
                        used.add(database);
                        break;
                    }
                    else {
                        try {
                            wait();
                        }
                        catch(InterruptedException ex) {
                            ex.printStackTrace(System.err);
                        }
                    }
                }
                break;
            }
            case RELEASE: {
                if(used.remove(database)) {
                    available.add(database);
                }
                database.closeOpenedDataSource();
                notifyAll();
                break;
            }
            case CLOSE: {
                while(true) {
                    if(!available.isEmpty()) {
                        database = available.remove(0);
                        database.close();
                    }
                    else if(!used.isEmpty()) {
                        try {
                            wait();
                        }
                        catch(InterruptedException ex) {
                            ex.printStackTrace(System.err);
                        }
                    }
                    else {
                        break;
                    }
                }
            }
        }        
        return database;
    }
}

