/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Execute a batch of an update SQL command with different parameters. 
 * For example:
 * <pre>
 * Database database = MySQLDatabase(...);
 * Batch updates = database.createBatch("INSERT INTO mitable (id, name, address) VALUES (?,?,?)");
 * updates.add(1,"John","Oxfort Street");
 * updates.add(2,"Richard", "Michigan Street");
 * updates.execute();
 * </pre>
 * <p>Un the updates are executed, then the batch object is closed and it cannot be used again.</p>
 * @author Jos&eacute; M. G&oacute;mez;
 */
public class Batch implements Closeable, AutoCloseable {
    /**
     * The statement to execute.
     */
    final private PreparedStatement statement;
    /**
     * The database connection.
     */
    final private Database database;
    /**
     * The number of statements in the batch.
     */
    private int size;

    /**
     * Constructor.
     * @param database the database which this batch will execute.
     * @param sql the SQL command.
     * @throws DatabaseException if a database access error occurs or this method is called on a closed connection
     */
    Batch(Database database, String sql) throws DatabaseException {
        try {
            this.database = database;
            statement = database.getConnection().prepareStatement(sql);
        } catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }
    
    /**
     * Add the SQL parameters. At least this must be executed once before the execute() method.
     * @param parameters The parameters of the SQL command.
     * @throws DatabaseException if a database access error occurs or this method is 
     * called on a closed PreparedStatement
     */
    public void add(Object... parameters) throws DatabaseException {
        try {
            Database.addParameters(statement, parameters);
            statement.addBatch();
            size++;
        }  catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }
    
    /**
     * Submits a batch of commands to the database for execution and if all commands 
     * execute successfully, returns an array of update counts. This method close the
     * batch object and it is no available for reuse.
     * The int elements of the array that is returned are ordered to correspond to 
     * the commands in the batch, which are ordered according to the order in which 
     * they were added to the batch. The elements in the array returned by the method 
     * executeBatch may be one of the following:
     * <ol>
     * <li>A number greater than or equal to zero -- indicates that the command was 
     * processed successfully and is an update count giving the number of rows in the 
     * database that were affected by the command's execution</li>
     * <li>A value of SUCCESS_NO_INFO -- indicates that the command was processed successfully 
     * but that the number of rows affected is unknown</li>
     * <p>If one of the commands in a batch update fails to execute properly, this method 
     * throws a BatchUpdateException, and a JDBC driver may or may not continue to 
     * process the remaining commands in the batch. However, the driver's behavior 
     * must be consistent with a particular DBMS, either always continuing to process 
     * commands or never continuing to process commands. If the driver continues 
     * processing after a failure, the array returned by the method 
     * BatchUpdateException.getUpdateCounts will contain as many elements as there 
     * are commands in the batch, and at least one of the elements will be the following:</p>
     * <li>A value of EXECUTE_FAILED -- indicates that the command failed to execute 
     * successfully and occurs only if a driver continues to process commands after a command fails</li>
     * </ol>
     * <p>The possible implementations and return values have been modified in the Java 2 SDK,
     * Standard Edition, version 1.3 to accommodate the option of continuing to proccess commands 
     * in a batch update after a BatchUpdateException obejct has been thrown</p>
     * @return an array of update counts containing one element for each command 
     * in the batch. The elements of the array are ordered according to the order 
     * in which commands were added to the batch.
     * @throws DatabaseException if a database access error occurs, this method is 
     * called on a closed data source or the driver does not support batch statements. 
     * Throws BatchUpdateException (a subclass of SQLException) if one of the commands 
     * sent to the database fails to execute properly or attempts to return a result set.
     */
    public int[] execute() throws DatabaseException {
        if(size > 0) {
            try {
                try {
                    return statement.executeBatch();
                } finally {
                    close();
                }
            } catch (SQLException ex) {
                throw new DatabaseException(ex);
            }
        }
        return new int[0];
    }
    
    @Override
    public void close() throws DatabaseException {
        try {
            statement.close();
            database.removeOpenedDataSource(this);
        } catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }
    
}
