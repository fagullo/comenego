/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import java.sql.SQLException;

/**
 * Simple wrapper to work with databases that allow transactions.
 *
 * @author Jos&eacute; M. G&oacute;mez;
 * @author Felipe Jos&eacute; Sell&eacute;s Tur
 */
abstract public class RemoteDatabase extends Database {
    /**
     * The host where the remote database is.
     */
    private final String host;
    /**
     * The port to connect with.
     */
    private final Integer port;

    /**
     * Create a connection with the database.
     *
     * @param driver The jDBC driver to connect with the database.
     * @param url The connection URL to the database.
     * @param host the database server host.
     * @param user the user to connect with the database.
     * @param password the user password to connect with the database.
     * @param databaseName the database name.
     * @throws es.ua.db.DatabaseException If any error occurs with the connection with the database.
     */
    protected RemoteDatabase(String driver, String url, String host, String user, String password, String databaseName) throws DatabaseException {
        super(driver, url, user, password,  databaseName);
        this.host = host;
        this.port = null;
    }

    /**
     * Create a connection with the database.
     *
     * @param driver The jDBC driver to connect with the database.
     * @param url The connection URL to the database.
     * @param host the database server host.
     * @param port the port to connect with the database server.
     * @param user the user to connect with the database.
     * @param password the user password to connect with the database.
     * @throws es.ua.db.DatabaseException If any error occurs with the connection with the database.
     */
    public RemoteDatabase(String driver, String url, String host, Integer port, String user, String password, String databaseName) throws DatabaseException {
        super(driver, url, user, password, databaseName);
        this.host = host;
        this.port = port;
    }

    /**
     * Allow connection to start transaction
     *
     * @throws es.ua.db.DatabaseException if an SQLException occurs starting
     * transaction
     */
    public void startTransaction() throws DatabaseException {
        try {
            getConnection().setAutoCommit(false);
        } catch (SQLException ex) {
            throw new DatabaseException("An error has occured starting transaction: " + ex.getMessage() + ".", ex);
        }
    }

    /**
     * Execute the transaction operations in the database
     *
     * @throws es.ua.db.DatabaseException if an SQLException occurs when commit
     * or finish the transaction
     */
    public void commit() throws DatabaseException {
        try {
            getConnection().commit();
            getConnection().setAutoCommit(true);
        } catch (SQLException ex) {
            throw new DatabaseException("An error has occured in the database commit: " + ex.getMessage(), ex);
        }
    }

    /**
     * Cancel the transaction operations in the database
     *
     * @throws es.ua.db.DatabaseException if a SQLException occurs when rollback
     * or finish the transaction
     */
    public void rollback() throws DatabaseException {
        try {
            getConnection().rollback();
            getConnection().setAutoCommit(true);
        } catch (SQLException ex) {
            throw new DatabaseException("An error has occured in the rollback: " + ex.getMessage(), ex);
        }
    }

    /**
     * @return the host
     */
    public String getHost() {
        return host;
    }

    /**
     * @return the port
     */
    public Integer getPort() {
        return port;
    }
}
