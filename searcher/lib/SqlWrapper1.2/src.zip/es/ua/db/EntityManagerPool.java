/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import static es.ua.db.EntityManagerPool.EntityManagerPoolAction.CLOSE;
import static es.ua.db.EntityManagerPool.EntityManagerPoolAction.GET;
import static es.ua.db.EntityManagerPool.EntityManagerPoolAction.RELEASE;
import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * This class create a pool of entity manager connections until a maximum of
 * connections. If this maximum is achieved, then the connections are shared
 * between processes in order to avoid that the same connection is used by two
 * different processes at the same time and synchronizing the access to read and write
 * in the same entity manager.
 * <p>This entity manager pool is useful for control the access to several threads to the
 * same database using a maximum of connections (instead of creating a connection
 * for each thread). Another advantage is that only open once each connection.</p>
 * <h2>Example of use</h2>
 * <p>In this example, a pool with a maximum of only 5 connections is created and their are used
 * by 100 different threads.</p>
 * <pre>
 * EntityManager em = Persistence.createEntityManagerFactory(persistenceUnitName, properties).createEntityManager();
 * EntityManagerPool pool = new EntityManager(em, 5);
 * ...
 * for(int i = 0; i < 100; i++) {
 *   new Thread() {
 *     public run() {
 *       while(true) {
 *         // do something
 *         ...
 *         EntityManager em = pool.get(); // Obtain a free entity manager connection
 *         // do something with the entity manager
 *         ...
 *         pool.release(em); // Release the database connection
 *         // do something
 *         ...
 *       }
 *     }
 *   }.start();
 * }
 * </pre>
  * @author Jos&eacute; M. G&oacute;mez;
 */
public class EntityManagerPool {
    /**
     * The entity manager used in the constructor of this pool of entity managers. 
     * From this, the following connections will be created using the same
     * connection data that this one.
     */
    final private EntityManager initialEM;
    /**
     * The maximum number of connections.
     */
    private final int maxConnections;
    /**
     * The list of available entity managers.
     */
    private final List<EntityManager> available;
    /**
     * A set with all entity managers witch are being used.
     */
    private final Set<EntityManager> used;

    /**
     * @return the maximum entity manager connections to store in this pool.
     */
    public int getMaxConnections() {
        return maxConnections;
    }

    /**
     * Create a EntityManager instance from the initial one.
     * @return The new entity manager.
     */
    private EntityManager newEntityManagerInstance() {
        EntityManagerFactory entityManagerFactory = initialEM.getEntityManagerFactory();
        return entityManagerFactory.createEntityManager();
    }

    /** 
     * The different actions to do in this database pool. GET is to
     * obtain a new free database connection or wait is it is not free;
     * RELEASE is to release a database connection; and, CLOSE, is for close
     * all database connections.
     */
    static enum EntityManagerPoolAction { GET, RELEASE, CLOSE};
    
    /**
     * Create a entity manager connection pool to allow only a maximum of connections 
     * from a connected entity manage. It is necessary to open a initial entity manager connection and
     * this class open the following ones as the connections are requesting to
     * the maximum connections. When this maximum is achieved, the following requests
     * are stopped until a connexions will free.
     * @param em
     * @param maxConnections The maximum of database connections.
     */
    public EntityManagerPool(EntityManager em, int maxConnections) {
        initialEM = em;
        this.maxConnections = maxConnections;
        available = new ArrayList<EntityManager>(maxConnections);
        available.add(em);
        // The tabla hash must be a 1.33333... bigger than the number of elements to contain.
        used = new HashSet<EntityManager>((int)Math.round(maxConnections / 0.75 + 0.5));
    }
    
    /**
     * Create a entity manager connection pool to allow only a maximum of connections.
     * This class open the following ones as the connections are requesting to
     * the maximum connections. When this maximum is achieved, the following requests
     * are stopped until a connexions will free.
     * @param persistenceUnitName The name of the persistence unit.
     * @param properties Additional properties to use when creating the factory. 
     * The values of these properties override any values that may have been configured elsewhere. 
     * @param maxConnections The maximum of database connections.
     */
    public EntityManagerPool(String persistenceUnitName, Map properties, int maxConnections) {
        this(Persistence.createEntityManagerFactory(persistenceUnitName, properties).createEntityManager(), maxConnections);
    }
    
    /**
     * reate an entity manager connection pool to allow only a maximum of connections 
     * with that name of a persistence unit. 
     * This class open the following ones as the connections are requesting to
     * the maximum connections. When this maximum is achieved, the following requests
     * are stopped until a connexions will free.
     * @param persistenceUnitName The name of the persistence unit.
     * @param maxConnections The maximum of database connections.
     */
    public EntityManagerPool(String persistenceUnitName, int maxConnections) {
        this(persistenceUnitName, new HashMap(), maxConnections);
    }
    
    /**
     * Create an entity manager connection pool to allow only a maximum of connections 
     * with that name of a persistence unit and an opened initial database. After
     * this operation the database can be closed.
     * This class open the following ones as the connections are requesting to
     * the maximum connections. When this maximum is achieved, the following requests
     * are stopped until a connexions will free.
     * @param persistenceUnitName The name of the persistence unit.
     * @param database The database with the connection data. This database is never 
     * used again and can be closed after of creating the pool.
     * @param maxConnections The maximum of entity manager connections.
     */
    public EntityManagerPool(String persistenceUnitName, Database database, int maxConnections) {
        this(persistenceUnitName, createPropertiesMap(database), maxConnections);
    }
    
    /**
     * Obtain the connection properties from a database.
     * @param database The database to obtain the connection properties.
     * @return The map with the properties.
     */
    static private Map createPropertiesMap(Database database) {
        HashMap map = new HashMap();
        map.put("javax.persistence.jdbc.url", database.getURL());
        map.put("javax.persistence.jdbc.driver", database.getDriver());
        map.put("javax.persistence.jdbc.user", database.getUser());
        map.put("javax.persistence.jdbc.password", database.getPassword());
        return map;
    }
    
    /**
     * Obtain an entity manager connection from this pool. If there is already a 
     * released entity manager connection, then return it; if there isn't a released database
     * and the number of connections don't achieve the maximum, then create a new one and
     * return it; finally, if there isn't a released database and the number of
     * connections has achieved the maximum, then wait for release one.
     * @return a released entity manager connection.
     */
    public EntityManager get() {
        return sync(GET, null);
    }
    
    /**
     * Release a used entity manager. When a entity manager connection form this pool is
     * already used, this method must be called to indicate that this entity manager
     * can be used for other process. If there is an active transaction then 
     * the rollback will be executed.
     * @param em The entity manager to release.
     */
    public void release(EntityManager em) {
        sync(RELEASE, em);
    }
    
    /**
     * Close all entity managers of this pool. If there are entity manager being used
     * then, this method waits for its freedom.
     */
    public void close() {
        sync(CLOSE, null);
    }
    
    /**
     * This method synchronizes the GET, RELEASE and CLOSE operations.
     * @param action The action to do.
     * @param em for the RELEASE action, the entity manager to release, otherwise set to null.
     * @return for the GET action, return the next free entity manager connection.
     */
    private synchronized EntityManager sync(EntityManagerPoolAction action, EntityManager em) {
        switch(action) {
            case GET: {
                while(true) {
                    if(!available.isEmpty()) {
                        em = available.remove(0);
                        // TODO: ¿Se puede comprobar si la conexión sigue abierta?
                        used.add(em);
                        break;
                    }
                    else if(available.size() + used.size() < getMaxConnections()) {
                        em = newEntityManagerInstance();
                        used.add(em);
                        break;
                    }
                    else {
                        try {
                            wait();
                        }
                        catch(InterruptedException ex) {
                            ex.printStackTrace(System.err);
                        }
                    }
                }
                break;
            }
            case RELEASE: {
                if(em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                if(used.remove(em)) {
                    available.add(em);
                }
                // TODO: ¿ Poner un em.clear() ?
                notifyAll();
                break;
            }
            case CLOSE: {
                while(true) {
                    if(!available.isEmpty()) {
                        em = available.remove(0);
                        em.close();
                    }
                    else if(!used.isEmpty()) {
                        try {
                            wait();
                        }
                        catch(InterruptedException ex) {
                            ex.printStackTrace(System.err);
                        }
                    }
                    else {
                        break;
                    }
                }
            }
        }        
        return em;
    }
}
