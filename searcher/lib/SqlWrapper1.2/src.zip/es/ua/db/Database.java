/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import es.ua.db.Table.TableOrdering;
import static es.ua.db.Table.TableOrdering.DESCENDENT;
import es.ua.db.Trigger.ActionOperation;
import es.ua.db.Trigger.ActionTime;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/**
 * This class allows to use a database connection easily, simplifying the
 * most common operation and encapsulating tables and queries in JAVA objects.
 * The subclass of this class are the different kind of database (MySQLDatabase, 
 * OracleDatabase, SQLServerDatabase, even included AccessDatabase).
 * In order to build a database connection, you can choose the database subclass
 * and create a new instance. 
 * <p>For example, in order to add a record in the table 'my_table' of the database
 * 'my_database' from a MySQL server, you can do the following:</p>
 * <pre>
 * Database database = new MySQLDatabase(host, user, password, "my_database");
 * Table table = database.getTable("my_table");
 * table.append();
 * table.setField("id",1);
 * table.setField("a_float_field", 2.0f);
 * table.setField("a_string_field", "a value");
 * table.commit();
 * table.close();
 * database.close();
 * </pre>
 * <p>Also, you can make and use queries as following:</p>
 * <pre>
 * Database database = new MySQLDatabase(host, user, password, "my_database");
 * Query query = database.executeQuery("SELECT * FROM my_table WHERE id > ?", 10f);
 * for(query.first(); !query.isEof(); query.next()) {
 *   int id = (Integer) query.getField("id");
 *   float f = (Float) query.getField("a_float_field");
 *   String s = (Float) query.getField("a_string_field");
 *   // Do something
 *   ...
 * }
 * query.close();
 * database.close();
 * </pre>
 * 
 * @author Jos&eacute; M. G&oacute;mez
 * @author Felipe Jos&eacute; Sell&eacute;s Tur
 */
abstract public class Database implements Closeable, AutoCloseable {
    /** The user to connect with */
    private final String user;
    /** The password for that user */
    private final String password;
    /** The connection with the database. */
    private final Connection connection;
    /** The connection URL with the database. */
    private final String url;
    /**
     * The database name.
     */
    private final String name;
    /** The opened objects (queries and tables). */
    private final List<Closeable> openedObjects = Collections.synchronizedList(new ArrayList<Closeable>());


    /**
     * Create a Database wrapper for dealing with the database using a database
     * connection.
     * @param driver The jDBC driver to connect with the database.
     * @param url The connection URL to the database.
     * @param user the user to connect with the database.
     * @param password the password for that user..
     * @param dbName The database name.
     * @throws es.ua.db.DatabaseException If any error occurs with the connection with the database.
     */
    protected Database(String driver, String url, String user, String password, String dbName) throws DatabaseException {
        try {
            this.connection = createConnection(driver, url, user, password);
            this.url = url;
            this.user = user;
            this.password = password;
            this.name = dbName;
        } catch (ClassNotFoundException ex) {
            throw new DatabaseException("The driver '" + driver + "' is not in the project's classpath", ex);
        } catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }
    
    /**
     * Create a Database wrapper for dealing with the database using a database
     * connection without user nor password.
     * @param driver The jDBC driver to connect with the database.
     * @param url The connection URL to the database.
     * @param dbName The database name.
     * @throws es.ua.db.DatabaseException If any error occurs with the connection with the database.
     */
    protected Database(String driver, String url, String dbName) throws DatabaseException {
        try {
            this.connection = createConnection(driver, url);
            this.url = url;
            this.user = null;
            this.password = null;
            this.name = dbName;
        } catch (ClassNotFoundException ex) {
            throw new DatabaseException("The driver '" + driver + "' is not in the project's classpath", ex);
        } catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }
    
    /**
     * Obtain the URI with the parameters to connect with the database.
     * @return An string which represents the URI.
     */
    public final String getURL() {
        return url;
    }

    /** Obtain a database connection without create a Database instance.
	 *
     * @param driver the jdbc driver to connect with the database.
	 * @param url the URL to connect with the database.
	 * @return the database connection
	 * @throws ClassNotFoundException if the jdbc library for this driver was not included in the project
	 * @throws SQLException if a database access error occurs
	 */
    static public Connection createConnection(String driver, String url) throws ClassNotFoundException, SQLException {
        Class.forName(driver);
        return DriverManager.getConnection(url.toString());
    }
    
    /** Obtain a database connection without create a Database instance.
	 *
     * @param driver the jdbc driver to connect with the database.
	 * @param url the URL to connect with the database.
	 * @param user the user to connect
	 * @param password the password for that user
	 * @return the database connection
	 * @throws ClassNotFoundException if the jdbc library for this driver was not included in the project
	 * @throws SQLException if a database access error occurs
     */
    static public Connection createConnection(String driver, String url, String user, String password) throws ClassNotFoundException, SQLException {
        Class.forName(driver);
        return DriverManager.getConnection(url, user, password);
    }
    
    /** Obtain a database connection without create a Database instance.
	 *
     * @param driver the jdbc driver to connect with the database.
	 * @param url the URL to connect with the database.
	 * @param info a list of arbitrary string tag/value pairs as connection arguments; 
     *  normally at least a "user" and "password" property should be included
	 * @return the database connection
	 * @throws ClassNotFoundException if the jdbc library for mysql was not included in the project
	 * @throws SQLException if a database access error occurs
     */
    static public Connection createConnection(String driver, String url, Properties info) throws ClassNotFoundException, SQLException {
        Class.forName(driver);
        return DriverManager.getConnection(url, info);
    }
    
    /**
     * @return the driver to connect with the database.
     */
    abstract public String getDriver();
    
    /**
     * Create a new connections with the database based on the current connection.
     * 
     * @return A database with the connection.
     * @throws es.ua.db.DatabaseException If any exception occurs creating the new
     * connection.
     */
    abstract public Database newInstance() throws DatabaseException;
    
    /**
     * Check if the database is already closed.
     * @return true if the databases is closed, false otherwise.
     * @throws DatabaseException if a database access error occurs.
     */
    public boolean isClose() throws DatabaseException {
        try {
            return connection.isClosed();
        } catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }
    
    /**
     * Returns true if the connection has not been closed and is still valid. 
     * The driver shall submit a query on the connection or use some other mechanism 
     * that positively verifies the connection is still valid when this method is called.
     * The query submitted by the driver to validate the connection shall be executed 
     * in the context of the current transaction.
     * @param timeout The time in seconds to wait for the database operation used to 
     * validate the connection to complete. If the timeout period expires before 
     * the operation completes, this method returns false. A value of 0 indicates 
     * a timeout is not applied to the database operation.
     * @return if the connection is valid, false otherwise 
     * @throws DatabaseException if the value supplied for timeout is less then 0.
     */
    public boolean isValid(int timeout) throws DatabaseException {
        try {
            return connection.isValid(timeout);
        } catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }
    /**
     * @return The database name. This value could be null if the connection is 
     * to the database manager instead of to a specific database.
     */
   public String getName() {
       return name;
   }

    /**
     * Create a database from a connection.
     *
     * @param conn The connection with the database server.
     * @param name The database name.
     * @return True if the database has been executed properly, false otherwise.
     * @throws SQLException If ocurs any error with the database creation.
     */
    static public boolean createDatabase(Connection conn, String name) throws SQLException {
        return executeUpdate(conn, "CREATE DATABASE " + name + " DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;");
    }

    /**
     * Close the connection with the database.
     *
     * @throws DatabaseException
     */
    public void close() throws DatabaseException {
        try {
            closeOpenedDataSource();
            getConnection().close();
        } catch (SQLException ex) {
            throw new DatabaseException(ex.getMessage(), ex);
        }
    }

    /**
     * Remove all table rows which fulfil a condition.
     *
     * @param tableName the table name
     * @param condition the condition
     * @return true if the sql operation was executed successfully, else false.
     * @throws DatabaseException If there is any problem accessing to the
     * database.
     */
    public boolean deleteRows(String tableName, String condition) throws DatabaseException {
        return executeUpdate("DELETE FROM " + tableName + " WHERE " + condition);
    }
    
    /**
     * Remove a database from its name.
     * @param connection the connection with the database manager.
     * @param databaseName the database name to remove.
     * @return true if the database is removed successfully, false otherwise.
     * @throws SQLException If there is any problem accessing to the database.
     */
    static boolean dropDatabase(Connection connection, String databaseName) throws SQLException {
        return executeUpdate(connection, "drop database if exists " + databaseName);
    }

    /**
     * Remove a database from its name.
     * @param connection the connection with the database manager.
     * @param userName the user name to remove.
     * @return true if the database is removed successfully, false otherwise.
     * @throws SQLException If there is any problem accessing to the database.
     */
    static boolean dropUser(Connection connection, String userName) throws SQLException {
        return executeUpdate(connection, "drop user " + userName);
    }
    
    /**
     * Obtain a table from the database.
     *
     * @param tableName The name of the database table to retrieve.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     */
    public Table getTable(String tableName) throws DatabaseException {
        return getTable(tableName, null, null, null, 0, 0);
    }
    
    /**
     * Obtain a table from the database.
     *
     * @param tableName The name of the database table to retrieve.
     * @param from From which row starts the rows of this table.
     * @param size Number of rows to contain this table.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     */
    public Table getTable(String tableName, int from, int size) throws DatabaseException {
        return getTable(tableName, null, null, null, from, size);
    }
    
    /**
     * Obtain a table from the database.
     *
     * @param tableName The name of the database table to retrieve.
     * @param size Number of rows to contain this table.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     */
    public Table getTable(String tableName, int size) throws DatabaseException {
        return getTable(tableName, null, null, null, 0, size);
    }

    /**
     * Obtain a table from the database ordered by the fields specified in
     * orderBy.
     *
     * @param tableName The name of the database table to retrieve.
     * @param orderBy The name of fields, split by commas which the table will
     * be ordered.
     * @param orderMode The table order mode (acendent or descedent).
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     * @see TableOrdering#ASCENDENT
     * @see TableOrdering#DESCENDENT
     */
    public Table getTable(String tableName, String orderBy, TableOrdering orderMode) throws DatabaseException {
        return getTable(tableName, null, orderBy, orderMode, 0, 0);
    }
    
    /**
     * Obtain a table from the database ordered by the fields specified in
     * orderBy.
     *
     * @param tableName The name of the database table to retrieve.
     * @param orderBy The name of fields, split by commas which the table will
     * be ordered.
     * @param orderMode The table order mode (acendent or descedent).
     * @param from From which row starts the rows of this table.
     * @param size Number of rows to contain this table.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     * @see TableOrdering#ASCENDENT
     * @see TableOrdering#DESCENDENT
     */
    public Table getTable(String tableName, String orderBy, TableOrdering orderMode, int from, int size) throws DatabaseException {
        return getTable(tableName, null, orderBy, orderMode, from, size);
    }
    
    /**
     * Obtain a table from the database ordered by the fields specified in
     * orderBy.
     *
     * @param tableName The name of the database table to retrieve.
     * @param orderBy The name of fields, split by commas which the table will
     * be ordered.
     * @param orderMode The table order mode (acendent or descedent).
     * @param size Number of rows to contain this table.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     * @see TableOrdering#ASCENDENT
     * @see TableOrdering#DESCENDENT
     */
    public Table getTable(String tableName, String orderBy, TableOrdering orderMode, int size) throws DatabaseException {
        return getTable(tableName, null, orderBy, orderMode, 0, size);
    }

    /**
     * Obtain a filtered table from the database.
     *
     * @param tableName The name of the database table to retrieve.
     * @param filter Filter the table with this condition.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     */
    public Table getTable(String tableName, String filter) throws DatabaseException {
        return getTable(tableName, filter, null, null, 0, 0);
    }
    
    /**
     * Obtain a filtered table from the database.
     *
     * @param tableName The name of the database table to retrieve.
     * @param filter Filter the table with this condition.
     * @param from From which row starts the rows of this table.
     * @param size Number of rows to contain this table.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     */
    public Table getTable(String tableName, String filter, int from, int size) throws DatabaseException {
        return getTable(tableName, filter, null, null, from, size);
    }
    
    /**
     * Obtain a filtered table from the database.
     *
     * @param tableName The name of the database table to retrieve.
     * @param filter Filter the table with this condition.
     * @param size Number of rows to contain this table.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     */
    public Table getTable(String tableName, String filter, int size) throws DatabaseException {
        return getTable(tableName, filter, null, null, 0, size);
    }
    /**
     * Obtain a filtered table from the database ordered by the fields specified
     * in orderBy.
     *
     * @param tableName The name of the database table to retrieve.
     * @param filter Filter the table with this condition.
     * @param orderBy The name of fields, split by commas which the table will
     * be ordered.
     * @param orderMode The table order mode (acendent or descedent).
     * @param from From which row starts the rows of this table.
     * @param size Number of rows to contain this table.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     * @see TableOrdering#ASCENDENT
     * @see TableOrdering#DESCENDENT
     */
    public Table getTable(String tableName, String filter, String orderBy, TableOrdering orderMode, int from, int size) throws DatabaseException {
        try {
            String sql = "SELECT * FROM `" + tableName + "`";
            if(filter != null) {
                sql += " WHERE " + filter;
            }
            if(orderBy != null) {
                sql += " ORDER BY " + orderBy + (orderMode == DESCENDENT ? " DESC" : "");
            }
            if(from > 0 || size > 0) {
                sql += "LIMIT ";
            }
            if(from > 0) {
                if(size <= 0) {
                    throw new DatabaseException("You cannot define the from without size parameter in getTable() method.");
                }
                sql += from + ",";
            }
            if(size > 0) {
                sql += size;
            }
            Statement statement = getConnection().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = statement.executeQuery(sql);
            Table table = new Table(this, tableName, rs, filter);
            openedObjects.add(table);
            return table;
        } catch (SQLException ex) {
            throw new DatabaseException("A database error has ocurred: " + ex.getMessage() + ".", ex);
        }
    }
    
    /**
     * Obtain a filtered table from the database ordered by the fields specified
     * in orderBy.
     *
     * @param tableName The name of the database table to retrieve.
     * @param filter Filter the table with this condition.
     * @param orderBy The name of fields, split by commas which the table will
     * be ordered.
     * @param orderMode The table order mode (acendent or descedent).
     * @param size Number of rows to contain this table.
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     * @see TableOrdering#ASCENDENT
     * @see TableOrdering#DESCENDENT
     */
    public Table getTable(String tableName, String filter, String orderBy, TableOrdering orderMode, int size) throws DatabaseException {
        return getTable(tableName, filter, orderBy, orderMode, 0, size);
    }

    /**
     * Obtain a filtered table from the database ordered by the fields specified
     * in orderBy.
     *
     * @param tableName The name of the database table to retrieve.
     * @param filter Filter the table with this condition.
     * @param orderBy The name of fields, split by commas which the table will
     * be ordered.
     * @param orderMode The table order mode (acendent or descedent).
     * @return the table in the datase with the name 'tableName'.
     * @throws DatabaseException if a database access error occurs or
     * this method is called on a closed connection
     * @see TableOrdering#ASCENDENT
     * @see TableOrdering#DESCENDENT
     */
    public Table getTable(String tableName, String filter, String orderBy, TableOrdering orderMode) throws DatabaseException {
        return getTable(tableName, filter, orderBy, orderMode, 0, 0);
    }

    /**
     * Execute a query and return the query result from a sql sentence.
     *
     * @param sql The sql command.
     * @param parameters The parameters of the sql command.
     * @return A object Query with the result of the query.
     * @throws DatabaseException If there is any problem accessing to the
     * database.
     */
    public Query executeQuery(String sql, Object... parameters) throws DatabaseException {
        try {
            ResultSet rs = executeQuery(getConnection(), sql, parameters);
            Query query = new Query(this, sql, rs);
            openedObjects.add(query);
            return query;
        } catch (SQLException ex) {
            throw new DatabaseException("A database error has ocurred: " + ex.getMessage() + ".", ex);
        }
    }

    /**
     * Execute a SQL query with a connection.
     *
     * @param conn The connexion with the database.
     * @param sql The sql sentence.
     * @param parameters The parameters of the sql command.
     * @return A result set.
     * @throws SQLException If there is any problem accessing to the database.
     */
    static public ResultSet executeQuery(Connection conn, String sql, Object... parameters) throws SQLException {
        PreparedStatement statement = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        addParameters(statement, parameters);
        return statement.executeQuery();
    }

    /**
     * Execute a sql operation in the database.
     *
     * @param sql The sql sentence.
     * @param parameters The parameters of the sql command.
     * @return true if the sql operation was executed successfully, else false.
     * @throws DatabaseException If there is any problem accessing to the
     * database.
     */
    public boolean executeUpdate(String sql, Object... parameters) throws DatabaseException {
        try {
            return executeUpdate(getConnection(), sql, parameters);
        } catch (SQLException ex) {
            throw new DatabaseException("A database error has ocurred: " + ex.getMessage() + ".", ex);
        }
    }

    /**
     * Execute a sql operation.
     *
     * @param conn The connection with the database
     * @param sql The sql sentence.
     * @param parameters The parameters of the sql command.
     * @return true if the sql operation was executed successfully, else false.
     * @throws SQLException If there is any problem accessing to the database.
     */
    static public boolean executeUpdate(Connection conn, String sql, Object... parameters) throws SQLException {
        PreparedStatement statement = conn.prepareStatement(sql);
        try {
            addParameters(statement, parameters);
            return statement.execute();
        } finally {
            statement.close();
        }
    }

    /**
     * Remove all registers from a table.
     *
     * @param tableName The name of the database table to retrieve.
     * @throws DatabaseException if a database access error occurs or this
     * method is called on a closed connection.
     * @see Table#deleteAll()
     */
    public void deleteAllRows(String tableName) throws DatabaseException {
        try {
            Statement statement = getConnection().createStatement();
            statement.execute("delete from " + tableName);
            statement.close();
        } catch (SQLException ex) {
            throw new DatabaseException("A database error has ocurred: " + ex.getMessage() + ".", ex);
        }
    }

    /**
     * Read a file and return its content.
     *
     * @param filePath The file path.
     * @param connection The connection with the database.
     * @throws FileNotFoundException if the file does not exist, is a directory
     * rather than a regular file, or for some other reason cannot be opened for
     * reading.
     * @throws IOException If an I/O error occurs.
     * @throws java.sql.SQLException If any SQLException occurs.
     */
    static public void executeSqlFile(String filePath, Connection connection) throws FileNotFoundException, IOException, SQLException {
        SQLExecutor executor = new SQLExecutor(new File(filePath), connection);
        try {
            executor.execute();
        } finally {
            executor.close();
        }
    }

    /**
     * Execute the SQL commands stored in a text file.
     * @param file the file to execute.
     * @throws FileNotFoundException if the file does not exist, is a directory
     * rather than a regular file, or for some other reason cannot be opened for
     * reading.
     * @throws IOException If an I/O error occurs.
     * @throws java.sql.SQLException If any SQLException occurs.
     */
    public void executeSqlFile(String file) throws FileNotFoundException, IOException, SQLException {
        executeSqlFile(file, connection);
    }
    
    /**
     * Execute the SQL commands stored in a reader.
     * @param reader the reader with the SQL commands.
     * @throws IOException If an I/O error occurs.
     * @throws java.sql.SQLException If any SQLException occurs.
     */
    public void executeSql(Reader reader) throws IOException, SQLException {
        SQLExecutor executor = new SQLExecutor(reader, connection);
        try {
            executor.execute();
        } finally {
            executor.close();
        }
    }
    
    /**
     * Execute the SQL commands stored in an input stream.
     * @param is the input stream with the SQL commands.
     * @throws IOException If an I/O error occurs.
     * @throws java.sql.SQLException If any SQLException occurs.
     */
    public void executeSql(InputStream is) throws IOException, SQLException {
        SQLExecutor executor = new SQLExecutor(is, connection);
        try {
            executor.execute();
        } finally {
            executor.close();
        }
    }
    
    /**
     * Execute the SQL commands stored in an input stream.
     * @param is the input stream with the SQL commands.
     * @param encoding the character encoding for the text in that input stream.
     * @throws IOException If an I/O error occurs.
     * @throws java.sql.SQLException If any SQLException occurs.
     */
    public void executeSql(InputStream is, String encoding) throws IOException, SQLException {
        SQLExecutor executor = new SQLExecutor(is, encoding, connection);
        try {
            executor.execute();
        } finally {
            executor.close();
        }
    }
    
    /** 
     * Create a batch of update commands with different parameters for the
     * same SQL command.
     * @param sql the SQL command to execute in batch mode.
     * @return an batch object in order to add parameters.
     * @throws DatabaseException if a database access error occurs or this method 
     * is called on a closed PreparedStatement
     * @see Batch
     */
    public Batch createBatch(String sql) throws DatabaseException {
        Batch batch = new Batch(this, sql);
        openedObjects.add(batch);
        return batch;
    }

    /**
     * @return the user to connect with the database.
     */
    public String getUser() {
        return user;
    }

    /**
     * @return the password for the database user.
     */
    public String getPassword() {
        return password;
    }

    /**
     * @return the connection to the database.
     */
    public Connection getConnection() {
        return connection;
    }
    
    /**
     * Add parameters of a statement. This method recognize the parameter type
     * and use the suitable method to modify the parameter.
     * @param statement the statement to execute.
     * @param parameters the parameters to add.
     * @throws SQLException if parameterIndex does not correspond to a parameter marker in the SQL statement; 
     * if a database access error occurs or this method is called on a closed data source.
     */
    static void addParameters(PreparedStatement statement, Object[] parameters) throws SQLException {
        for(int i = 1; i <= parameters.length; i++) {
            Object param = parameters[i - 1];
            if(param instanceof Array) {
                statement.setArray(i, (Array) param);
            } else if(param instanceof InputStream) {
                statement.setAsciiStream(i, (InputStream) param);
            } else if(param instanceof BigDecimal) {
                statement.setBigDecimal(i, (BigDecimal) param);
            } else if(param instanceof Blob) {
                statement.setBlob(i, (Blob) param);
            } else if(param instanceof Boolean) {
                statement.setBoolean(i, (Boolean)param);
            } else if(param instanceof Byte) {
                statement.setByte(i, (Byte)param);
            } else if(param instanceof Byte[]) {
                statement.setBytes(i, (byte[]) param);
            } else if(param instanceof Reader) {
                statement.setCharacterStream(i, (Reader) param);
            } else if(param instanceof Clob) {
                statement.setClob(i, (Clob) param);
            } else if(param instanceof Date) {
                statement.setDate(i, (Date) param);
            } else if(param instanceof java.util.Date) {
                statement.setDate(i, new Date(((java.util.Date) param).getTime()));
            } else if(param instanceof Double) {
                statement.setDouble(i, (Double)param);
            } else if(param instanceof Float) {
                statement.setFloat(i, (Float)param);
            } else if(param instanceof Calendar) {
                statement.setDate(i, new Date(((Calendar)param).getTimeInMillis()));
            } else if(param instanceof Integer) {
                statement.setInt(i, (Integer)param);
            } else if(param instanceof Long) {
                statement.setLong(i, (Long)param);
            } else if(param instanceof Ref) {
                statement.setRef(i, (Ref) param);
            } else if(param instanceof RowId) {
                statement.setRowId(i, (RowId) param);
            } else if(param instanceof SQLXML) {
                statement.setSQLXML(i, (SQLXML) param);
            } else if(param instanceof Short) {
                statement.setShort(i, (Short)param);
            } else if(param instanceof String) {
                statement.setString(i, (String) param);
            } else if(param instanceof Time) {
                statement.setTime(i, (Time) param);
            } else if(param instanceof Timestamp) {
                statement.setTimestamp(i, (Timestamp) param);
            } else if(param instanceof URL) {
                statement.setURL(i, (URL) param);
            } else {
                statement.setObject(i, param);
            }
        }
    }

    /** Remove all opened objects (queries and tables) when use this database connection.
     * 
     * @throws DatabaseException if a database access error occurs.
     */
    void closeOpenedDataSource() throws DatabaseException {
        while(!openedObjects.isEmpty()) {
            openedObjects.remove(0).close();
        }
    }

    /**
     * Remove the opened data source of this this database from the list.
     * @param dataSource The data source to remove.
     */
    synchronized void removeOpenedDataSource(Closeable closeable) {
        openedObjects.remove(closeable);
    }
    
    /**
     * Create a trigger for detect changes in the DB. This operation creates, at least,
     * one more independent connection with the database because the trigger needs
     * a exclusive connection for blocking it sometimes. 
     * 
     * <p>By default, the trigger retrieve the rows values which any insert, update or delete operation is made.
     * In some implementations of this feature for some JDBC drivers can have a high computational cost.
     * In the case of MySQL the implementation is very efficient because the row copy is made
     * in a memory temporary table although can require much memory if the operations are made
     * above a lot of rows.
     * In this case you won't activate the row copy you can use the method
     * {@link #createTrigger(es.ua.db.Table, es.ua.db.Trigger.ActionTime, es.ua.db.Trigger.ActionOperation, boolean) createTrigger} 
     * or
     * {@link #createTrigger(String, es.ua.db.Trigger.ActionTime, es.ua.db.Trigger.ActionOperation, boolean) createTrigger} 
     * to set the retrieveRows parameter to false.
     * </p>
     * 
     * @param table the table to detected the changes with.
     * @param time before or after it change.
     * @param operation what operation you wants detects (INSERT, UPDATE or DELETE).
     * @return a trigger which can be use for add listeners.
     * @throws DatabaseException if any database exception occurs.
     */
    public MySQLTrigger createTrigger(Table table, ActionTime time, ActionOperation operation) throws DatabaseException {
        throw new UnsupportedOperationException("Not supported yet for this database manager.");
    }
    
    /**
     * Create a trigger for detect changes in the DB. This operation creates, at least,
     * one more independent connection with the database because the trigger needs
     * a exclusive connection for blocking it sometimes.
     * @param table the table to detected the changes with.
     * @param time before or after it change.
     * @param operation what operation you wants detects (INSERT, UPDATE or DELETE).
     * @param retrieveRows if true, the trigger retrieve the rows values which any insert,
     * update or delete operation is made.
     * In some implementations of this feature for some JDBC drivers can have a high computational cost.
     * In the case of MySQL the implementation is very efficient because the row copy is made
     * in a memory temporary table although can require much memory if the operations are made
     * above a lot of rows. 
     * In this case you won't activate the row copy put its value to false.
     * @return a trigger which can be use for add listeners.
     * @throws DatabaseException if any database exception occurs.
     */
    public MySQLTrigger createTrigger(Table table, ActionTime time, ActionOperation operation, boolean retrieveRows) throws DatabaseException {
        throw new UnsupportedOperationException("Not supported yet for this database manager.");
    }
    
    /**
     * Create a trigger for detect changes in the DB. This operation creates, at least,
     * one more independent connection with the database because the trigger needs
     * a exclusive connection for blocking it sometimes. 
     * 
     * <p>By default, the trigger retrieve the rows values which any insert, update or delete operation is made.
     * In some implementations of this feature for some JDBC drivers can have a high computational cost.
     * In the case of MySQL the implementation is very efficient because the row copy is made
     * in a memory temporary table although can require much memory if the operations are made
     * above a lot of rows.
     * In this case you won't activate the row copy you can use the method
     * {@link #createTrigger(es.ua.db.Table, es.ua.db.Trigger.ActionTime, es.ua.db.Trigger.ActionOperation, boolean) createTrigger} 
     * or
     * {@link #createTrigger(String, es.ua.db.Trigger.ActionTime, es.ua.db.Trigger.ActionOperation, boolean) createTrigger} 
     * to set the retrieveRows parameter to false.
     * </p>
     * @param tableName the table name to detected the changes with.
     * @param time before or after it change.
     * @param operation what operation you wants detects (INSERT, UPDATE or DELETE).
     * @return a trigger which can be use for add listeners.
     * @throws DatabaseException if any database exception occurs.
     */
    public MySQLTrigger createTrigger(String tableName, ActionTime time, ActionOperation operation) throws DatabaseException {
        return createTrigger(getTable(tableName), time, operation);
    }
    
    /**
     * Create a trigger for detect changes in the DB. This operation creates, at least,
     * one more independent connection with the database because the trigger needs
     * a exclusive connection for blocking it sometimes. 
     * @param tableName the table name to detected the changes with.
     * @param time before or after it change.
     * @param operation what operation you wants detects (INSERT, UPDATE or DELETE).
     * @param retrieveRows if true, the trigger retrieve the rows values which any insert,
     * update or delete operation is made.
     * In some implementations of this feature for some JDBC drivers can have a high computational cost.
     * In the case of MySQL the implementation is very efficient because the row copy is made
     * in a memory temporary table although can require much memory if the operations are made
     * above a lot of rows. 
     * In this case you won't activate the row copy put its value to false.
     * @return a trigger which can be use for add listeners.
     * @throws DatabaseException if any database exception occurs.
     */
    public MySQLTrigger createTrigger(String tableName, ActionTime time, ActionOperation operation, boolean retrieveRows) throws DatabaseException {
        return createTrigger(getTable(tableName), time, operation, retrieveRows);
    }
}
