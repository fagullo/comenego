/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/** Simple wrapper to work with MySQL databases.
 *
 * @author Jos&eacute; M. G&oacute;mez;
 */
public class MySQLDatabase extends RemoteDatabase {
	/** The jdbc driver for MySQL. */
	static public final String DRIVER = "org.gjt.mm.mysql.Driver";
	/** The protocol for MySQL. */
	static public final String PROTOCOL = "jdbc:mysql://";

    /** Create a connection with the database.
	 *
	 * @param host the database server host.
	 * @param user the user to connect with the database.
	 * @param password the user password to connect with the database.
	 * @param databaseName the database name.
	 * @throws DatabaseException if a database access error occurs or the
	 *  JDBC driver is not in the classpath.
	 */
    public MySQLDatabase(String host, String user, String password, String databaseName) throws DatabaseException {
		this(host, null, user, password, databaseName);
	}

    /** Create a connection with the database.
	 *
	 * @param host the database server host.
         * @param port the port used to connect with MySQL.
	 * @param user the user to connect with the database.
	 * @param password the user password to connect with the database.
	 * @param databaseName the database name.
	 * @throws DatabaseException if a database access error occurs or the
	 *  JDBC driver is not in the classpath.
	 */
    public MySQLDatabase(String host, Integer port, String user, String password, String databaseName) throws DatabaseException {
        super(DRIVER, getURL(host, port, databaseName), host, port, user, password, databaseName);
    }

	/** Obtain a database connection without create a Database instance.
	 *
	 * @param host the database server host.
	 * @param port the database server port. If this argument is null, then the default value is used.
	 * @param databaseName the database name. If this argument is null, then return a connection with the MySql server.
	 * @param user the user to connect
	 * @param password the password for that user
	 * @return the database connection
	 * @throws ClassNotFoundException if the jdbc library for mysql was not included in the project
	 * @throws SQLException if a database access error occurs
	 */
	static public Connection createConnection(String host, Integer port, String databaseName, String user, String password) throws ClassNotFoundException, SQLException {
        String url = getURL(host, port, databaseName);
        return Database.createConnection(DRIVER, url, user, password);
	}
           
	/** Obtain a database server connection without neither create a Database instance nor connect with a specific database.
	 *
	 * @param host the database server host.
	 * @param port the database server port. If this argument is null, then the default value is used.
	 * @param user the user to connect
	 * @param password the password for that user
	 * @return the database connexion
	 * @throws ClassNotFoundException if the jdbc library for mysql was not included in the project
	 * @throws SQLException if a database access error occurs
	 */
	static public Connection createConnection(String host, Integer port, String user, String password) throws ClassNotFoundException, SQLException {
		return createConnection(host, port, null, user, password);
	}
        
        /** Obtain a database server connection without neither create a Database instance nor connect with a specific database.
	 *
	 * @param host the database server host.
	 * @param user the user to connect
	 * @param password the password for that user
	 * @return the database connexion
	 * @throws ClassNotFoundException if the jdbc library for mysql was not included in the project
	 * @throws SQLException if a database access error occurs
	 */
	static public Connection createConnection(String host, String user, String password) throws ClassNotFoundException, SQLException {
		return createConnection(host, null, null, user, password);
	}
    
    
    /** Obtain a database server connection without neither create a Database instance nor connect with a specific database.
	 *
	 * @param host the database server host.
	 * @param databaseName the database name. If this argument is null, then return a connection with the MySql server.
	 * @param user the user to connect
	 * @param password the password for that user
	 * @return the database connexion
	 * @throws ClassNotFoundException if the jdbc library for mysql was not included in the project
	 * @throws SQLException if a database access error occurs
	 */
	static public Connection createConnection(String host, String databaseName, String user, String password) throws ClassNotFoundException, SQLException {
		return createConnection(host, null, databaseName, user, password);
	}

    /**
     * Build the URL connection from the connection data.
     * @param host the database server host.
     * @param port the database server port. If this argument is null, then the default value is used.
	 * @param databaseName the database name. If this argument is null, then return a connection with the MySql server.
     * @return a string witch represents the connection URL.
     */
    static private String getURL(String host, Integer port, String databaseName) {
        return PROTOCOL + host + ((port != null) ? ":" + port :"") + 
                ((databaseName != null) ? "/" + databaseName: "") + "?autoReconnect=true&useServerPrepStmts=true&useCursorFetch=true";
    }
    
    @Override
    public String getDriver() {
        return DRIVER;
    }

    @Override
    public Database newInstance() throws DatabaseException {
        return new MySQLDatabase(getHost(), getPort(), getUser(), getPassword(), getName());
    }
    
    /**
     * Check if exists a database with the name 'databaseName'.
     * @param connection The connection with the database.
     * @param database The database name to search.
     * @return true if the database exists, false otherwise.
     * @throws SQLException If there is any problem accessing to the database.
     */
    static public boolean exists(Connection connection, String database) throws SQLException {
        ResultSet rs = executeQuery(connection, "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '" + database + "' LIMIT 1;");
        boolean result = rs.next();
        rs.getStatement().close();
        rs.close();
        return result;
    }

    /**
     * Create a user with all privileges to a specific database.
     * 
     * @param connection The connection to the database manager.
     * @param database The database name.
     * @param user The user name.
     * @param password The user password.
     * @param host the host from which it user has access. Use % for any host.
     * @return true if the user is created successfully.
     * @throws SQLException If there is any problem accessing to the database.
     */
    static public boolean createUser(Connection connection, String database, String user, String password, String host) throws SQLException {
        boolean result = executeUpdate(connection, "GRANT ALL ON `" + database + "`.* TO `" + user + "`@'" + host + "' IDENTIFIED BY '" + password + "'");
        if(result) {
            executeUpdate(connection, "FLUSH PRIVILEGES");
        }
        return result;
    }

    /**
     * Create a user with all privileges in this database.

     * @param user The user name.
     * @param password The user password.
     * @param host the host from which it user has access. Use % for any host.
     * @return true if the user is created successfully.
     * @throws SQLException If there is any problem accessing to the database.
     */
    public boolean createUser(String user, String password, String host) throws SQLException {
        return createUser(getConnection(), getName(), user, password, host);
    }
    
    @Override
    public MySQLTrigger createTrigger(Table table, MySQLTrigger.ActionTime time, MySQLTrigger.ActionOperation operation) throws DatabaseException {
        return new MySQLTrigger(this, table, time, operation, true);
    }
    
    @Override
    public MySQLTrigger createTrigger(Table table, MySQLTrigger.ActionTime time, MySQLTrigger.ActionOperation operation, boolean retrieveRows) throws DatabaseException {
        return new MySQLTrigger(this, table, time, operation, retrieveRows);
    }
    
}
