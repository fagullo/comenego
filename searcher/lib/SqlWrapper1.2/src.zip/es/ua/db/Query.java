/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import java.sql.ResultSet;

/**
 * Class which represents a no-modificable Query. With Query you can iterate
 * over the query rows as well as move to a specific row or obtain the value of its
 * fields.
 * <p>For more examples to use Query object you can see DataSource javadoc.</p>
 * 
 * @author Jos&eacute; M. G&oacute;mez;
 * @see DataSource
 */
public class Query extends DataSource {
	/** The sql statement of this Query. */
	private final String sql;

	/** Build a Query object from a ResultSet.
	 *
	 * @param database The database which this query belongs.
	 * @param sql The query that a generated the ResultSet.
	 * @param rs The ResultSet which represents this Query.
	 * @throws DatabaseException if a database access error occurs;
	 * this exception is called on a closed result set.
	 */
	Query(Database database, String sql, ResultSet rs) throws DatabaseException {
		super(database, rs);
		this.sql = sql;

	}

	@Override
	String getErrorMessagePrefix() {
		return "An error ocurred in the query:\n\n" + sql + "\n\n";
	}

	/**
	 * The sql statement of this Query.
	 * @return a string with the sql statement.
	 */
	public String getSql() {
		return sql;
	}

}
