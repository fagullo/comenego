/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.ua.db;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author jmgomez
 */
public class Row implements Map<String, Object> {

    final private DataSource source;

    public Row(DataSource source) {
        this.source = source;
    }

    @Override
    public int size() {
        return source.size();
    }

    @Override
    public boolean isEmpty() {
        return source.isEmpty();
    }

    @Override
    public boolean containsKey(Object key) {
        try {
            source.getFieldPosition((String) key);
            return true;
        } catch (DatabaseException ex) {
            return false;
        }
    }

    @Override
    public boolean containsValue(Object value) {
        try {
            for (int i = 0; i < source.fieldCount(); i++) {
                Object obj = source.getField(i);
                if (value.equals(obj)) {
                    return true;
                }
            }
        } catch (DatabaseException ex) {
            throw new RuntimeException(ex);
        }
        return false;
    }
    
    /**
     * Obtain a field form this 
     * @param name The field name.
     * @return The field data.
     * @throws DatabaseException If the field doesn't exists.
     */
    public Object getField(String name) throws DatabaseException {
        Object obj = get(name);
        if(obj == null) {
            if(source instanceof Table) {
                throw new DatabaseException("The field '" + name + "' doesn't exists in the table '" + ((Table)source).getName() + "'");
            } 
            if(source instanceof Query) {
                throw new DatabaseException("The field '" + name + "' doesn't exists in the SQL query: " + ((Query)source).getSql());
            }
            throw new DatabaseException("The field '" + name + "' doesn't exists in the data source.");
        }
        return obj;
    }

    @Override
    public Object get(Object key) {
        try {
            return source.getField((String) key);
        } catch (DatabaseException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public Object put(String key, Object value) {
        throw new UnsupportedOperationException("This map doesn't allow modification operations.");
    }

    @Override
    public Object remove(Object key) {
        throw new UnsupportedOperationException("This map doesn't allow modification operations.");
    }

    @Override
    public void putAll(Map m) {
        throw new UnsupportedOperationException("This map doesn't allow modification operations.");
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException("This map doesn't allow modification operations.");
    }

    @Override
    public Set keySet() {
        Set fields = new HashSet<String>();
        try {
            for (int i = 0; i < source.fieldCount(); i++) {
                fields.add(source.getFieldName(i));
            }
        } catch (DatabaseException ex) {
            throw new RuntimeException(ex);
        }
        return fields;
    }

    @Override
    public Collection values() {
        Collection<Object> fields = new ArrayList<Object>();
        try {
            for (int i = 0; i < source.fieldCount(); i++) {
                fields.add(source.getField(i));
            }
        } catch (DatabaseException ex) {
            throw new RuntimeException(ex);
        }
        return fields;
    }

    @Override
    public Set entrySet() {
        Set<Map.Entry> entries = new HashSet<Map.Entry>();
        try {
            for (int i = 0; i < source.fieldCount(); i++) {
                entries.add(new AbstractMap.SimpleImmutableEntry(source.getFieldName(i), source.getField(i)));
            }
        } catch (DatabaseException ex) {
            throw new RuntimeException(ex);
        }
        return entries;
    }
}
