/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import static es.ua.db.Trigger.ActionOperation.DELETE;
import static es.ua.db.Trigger.ActionOperation.INSERT;
import static es.ua.db.Trigger.ActionOperation.UPDATE;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Special class for deal with triggers in MySQL.
 *
 * @author Jos&eacute; M. G&oacute;mez;
 */
public class MySQLTrigger extends Trigger {

    /**
     * The lock id suffix.
     */
    public static final String LOCK_SUFFIX = "_lock";
    /**
     * The trigger id suffix.
     */
    public static final String TRIGGER_SUFFIX = "_tgr";
    /**
     * The tmp table suffix.
     */
    private static final String TABLE_SUFFIX = "_tmp";
    /**
     * Time to wait in seconds while getting the lock.
     */
    private static final long FOREVER = 9999999999l;
    /**
     * The trigger id.
     */
    private final String triggerName;
    /**
     * The lock name.
     */
    private final String lockName;
    /**
     * Database connection which will use for get the lock.
     */
    protected final Database lockDatabase;
    /**
     * The name of the temporary table for deleted or old updated rows values.
     */
    private String oldRowTableName = null;
    /**
     * * The name of the temporary table for inserted or new updated rows
     * values.
     */
    private String newRowTableName = null;

    /**
     * The name of the lock for blocking the trigger operations.
     */
    private final String procesingLockName;
    /**
     * The command for copy the new rows values to the tmp table.
     */
    private String insertNewRowsCommand = null;
    /**
     * The command for copy the old rows values to the tmp table.
     */
    private String insertOldRowsCommand = null;

    /**
     * Constructor.
     *
     * @param database the database connection. This connection is not directly
     * used but one or more new connections are created based on this connection
     * data.
     * @param table the table to listen the events.
     * @param time when the event is thrown, before or after the operation.
     * @param operation operation which will throw the event.
     * @throws DatabaseException if any database exception occurs.
     */
    MySQLTrigger(Database database, Table table, ActionTime time, ActionOperation operation, boolean retrieveRows) throws DatabaseException {
        super(database, table, time, operation, retrieveRows);
        // Create a new connection and some identifiers
        lockDatabase = database.newInstance();
        triggerName = table.getName() + '_' + getOperationString(operation) + TRIGGER_SUFFIX;
        lockName = table.getName() + '.' + java.util.UUID.randomUUID().toString() + LOCK_SUFFIX;
        procesingLockName = table.getName() + '.' + java.util.UUID.randomUUID().toString() + "_procesing" + LOCK_SUFFIX;
        // Obtain the connection id for kill queries with this id in order to broke the database lock when the trigger is thrown
        long connectionId = getConnectionId(this.database);
        // Creating temporary tables for store the inserted, modified or deleted row values
        if (retrieveRows && (operation == INSERT || operation == UPDATE)) {
            newRowTableName = table.getName() + "_NEW_" + getOperationString(operation) + TABLE_SUFFIX;
            createTmpTable(database, table, newRowTableName);
            insertNewRowsCommand = createInsertRowsCommand(table, newRowTableName, "NEW");
        }
        if (retrieveRows && (operation == DELETE || operation == UPDATE)) {
            oldRowTableName = table.getName() + "_OLD_" + getOperationString(operation) + TABLE_SUFFIX;
            createTmpTable(database, table, oldRowTableName);
            insertOldRowsCommand = createInsertRowsCommand(table, oldRowTableName, "OLD");
        }
        // Creating the BD trigger
        createTrigger(database, connectionId, triggerName, table.getName(), time, operation);
    }

    /**
     * Creates a temporary table with the same structure than another table.
     *
     * @param database the database connection.
     * @param table the table to copy the structure in the temporary table.
     * @param tmpName the temporary table name.
     * @throws DatabaseException if any database error occurs.
     */
    private void createTmpTable(Database database, Table table, String tmpName) throws DatabaseException {
        // Remove the previous temporary table if this exists
        database.executeUpdate("DROP TABLE IF EXISTS " + tmpName);
        // Build the command sentence to create the temporary table
        StringBuilder command = new StringBuilder();
        command.append("CREATE TABLE ").append(tmpName).append("(\n");
        for (int i = 1; i <= table.fieldCount(); i++) {
            String fieldName = table.getFieldName(i);
            String fieldType = table.getColumnTypeName(i);
            int fieldSize = table.getColumnSize(i);
            command.append(fieldName).append(' ').append(fieldType).append('(').append(fieldSize).append("),\n");
        }
        command.replace(command.length() - 2, command.length(), ") engine=MEMORY");
        // Create the temporary table with the same structure that 'table'
        database.executeUpdate(command.toString());
    }

    /**
     * Create a insert row command in order to copy the OLD or NEW values to
     * temporary table.
     *
     * @param table the table to copy from.
     * @param tmpName the table name to copy in.
     * @param prefix the column prefix for the trigger, that is, NEW (for the
     * new column values) or OLD (for the old column values).
     * @return a string which represents the SQL sentence to insert the NEW or
     * OLD column values into the temporary table.
     * @throws DatabaseException if any database error occurs.
     */
    private String createInsertRowsCommand(Table table, String tmpName, String prefix) throws DatabaseException {
        StringBuilder command = new StringBuilder();
        command.append("    INSERT INTO ").append(tmpName).append(" VALUES (");
        for (int i = 1; i <= table.fieldCount(); i++) {
            String fieldName = table.getFieldName(i);
            command.append(prefix).append('.').append(fieldName).append(',');
        }
        command.replace(command.length() - 1, command.length(), ");\n");
        return command.toString();
    }

    /**
     * Build a string with the SQL sentence to create the trigger in MySQL. This
     * trigger will try to get a lock and, if it is possible, then kill a lock
     * query executed by a application connection. This way, I can wait until
     * this trigger is thrown and, then, do the event actions.
     *
     * @param connectionId the connection id for kill the lock query,
     * @param triggerName the trigger id.
     * @param lockName the lock id.
     * @param tableName the table name which the trigger is associated with.
     * @param time when the trigger is thrown (BEFORE or AFTER the modification)
     * @param op the modification operation which throw the trigger (INSERT,
     * UPDATE or DELETE)
     * @return the SQL command for creating the trigger.
     */
    private void createTrigger(Database database, long connectionId, String triggerName, String tableName, ActionTime time, ActionOperation op) throws DatabaseException {
        // Remove the trigger if it already exists
        database.executeUpdate("DROP TRIGGER IF EXISTS " + triggerName);
        // Build the SQL command with the trigger
        StringBuilder command = new StringBuilder();
        command.append("CREATE TRIGGER ").append(triggerName).append(" ").append(getTimeString(time)).append(" ");
        command.append(getOperationString(op)).append(" ON ").append(tableName).append("\n");
        command.append("  FOR EACH ROW BEGIN\n");
        command.append("    DO GET_LOCK('").append(procesingLockName).append("', ").append(FOREVER).append(");\n");
        command.append("    KILL QUERY ").append(connectionId).append(";\n");
        // If the retrieve rows is enabled, then insert the command for copy the NEW or OLD column values to temporary table
        if (retrieveRows && (op == UPDATE || op == DELETE)) {
            command.append(insertOldRowsCommand);
        }
        if (retrieveRows && (op == UPDATE || op == INSERT)) {
            command.append(insertNewRowsCommand);
        }
        // Finish the trigger
        command.append("    DO RELEASE_LOCK('").append(procesingLockName).append("');\n");
        command.append(" END;\n");
        // Execute the trigger
        database.executeUpdate(command.toString());
    }

    @Override
    public void run() {
        try {
            try {
                // While the trigger object is not closed
                while (!thread.isInterrupted()) {
                    // Get the lock
                    lockDatabase.executeUpdate("SELECT GET_LOCK('" + lockName + "', " + FOREVER + ")");
                    // Get the same lock for sleep this thread until the BD trigger kill this query or the lock is release when the trigger object is closed
                    database.executeUpdate("SELECT GET_LOCK('" + lockName + "', " + FOREVER + ")");
                    // Release the triiger
                    lockDatabase.executeUpdate("DO RELEASE_LOCK('" + lockName + "')");
                    // If the thread is still alive, then execute the asociated event actions
                    synchronized (thread) {
                        try {
                            database.executeUpdate("SELECT GET_LOCK('" + procesingLockName + "', " + FOREVER + ")");
                            if (!thread.isInterrupted()) {
                                // If the retrieve rows is activated then retrieve the changed rows information
                                Table newRowTable = retrieveRows && (operation == INSERT || operation == UPDATE) ? database.getTable(newRowTableName) : null;
                                Table oldRowTable = retrieveRows && (operation == DELETE || operation == UPDATE) ? database.getTable(oldRowTableName) : null;
                                Iterator oldIterator = oldRowTable != null ? oldRowTable.iterator() : new ArrayList<Row>().iterator();
                                Iterator newIterator = newRowTable != null ? newRowTable.iterator() : new ArrayList<Row>().iterator();
                                try {
                                    // Depending on the operation to watch, fire the suitable event
                                    switch (operation) {
                                        case INSERT:
                                            fireInsertEvent(newIterator);
                                            break;
                                        case DELETE:
                                            fireDeleteEvent(oldIterator);
                                            break;
                                        case UPDATE:
                                            fireUpdateEvent(oldIterator, newIterator);
                                            break;
                                    }
                                } catch (Throwable ex) {
                                    // If any error occurs then fire the error event
                                    fireErrorEvent(ex);
                                } finally {
                                    // Remove all temporary data and close the opened tables
                                    if (newRowTable != null) {
                                        newRowTable.deleteAll();
                                        newRowTable.close();
                                    }
                                    if (oldRowTable != null) {
                                        oldRowTable.deleteAll();
                                        oldRowTable.close();
                                    }
                                }
                            }
                        } finally {
                            database.executeUpdate("DO RELEASE_LOCK('" + procesingLockName + "')");
                        }
                    }

                }
            } finally {
                synchronized (thread) {
                    // If the trigger object is closed or an exception is thrown,
                    // then remove the created trigger and temporary tables
                    database.executeUpdate("DROP TRIGGER IF EXISTS " + triggerName);
                    if (newRowTableName != null) {
                        database.executeUpdate("DROP TABLE " + newRowTableName);
                    }
                    if (oldRowTableName != null) {
                        database.executeUpdate("DROP TABLE " + oldRowTableName);
                    }
                    // Close the openned BD connections
                    lockDatabase.close();
                    database.close();
                }
            }
        } catch (Throwable ex) {
            Logger.getLogger(MySQLTrigger.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Obtain the connection id.
     *
     * @param database the database to obtain the id.
     * @return the connection id.
     * @throws DatabaseException if any database exception occurs.
     */
    private long getConnectionId(Database database) throws DatabaseException {
        Query query = database.executeQuery("SELECT CONNECTION_ID()");
        query.first();
        return ((BigDecimal) query.getField(1)).longValue();
    }

    @Override
    public void close() throws DatabaseException {
        synchronized (thread) {
            if (thread.isAlive()) {
                // if the thread is still alive, then interrupt it and remove all locks.
                thread.interrupt();
                lockDatabase.executeUpdate("DO RELEASE_LOCK('" + lockName + "')");
                database.executeUpdate("DO RELEASE_LOCK('" + lockName + "')");
                database.executeUpdate("DROP TRIGGER IF EXISTS " + triggerName);
            }
        }
    }
}
