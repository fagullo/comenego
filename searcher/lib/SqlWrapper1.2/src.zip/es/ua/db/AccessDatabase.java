/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

/**
 * Simple wrapper to work with Access databases.
 *
 *
 * @author Jos&eacute; M. G&oacute;mez;
 * @author Felipe Jos&eacute; Sell&eacute;s Tur
 */
public class AccessDatabase extends Database {
    /**
     * The jdbc driver for Access.
     */
    static public final String DRIVER = "sun.jdbc.odbc.JdbcOdbcDriver";

    /**
     * Create a connection with the database.
     *
     * @param dbName the access database file name.
     * @throws es.ua.db.DatabaseException If any error occurs with the connection with the database.
     */
    public AccessDatabase(String dbName) throws DatabaseException {
        super(DRIVER, getUrl(dbName), dbName);
    }

    /**
     * Create a connection with the database.
     *
     * @param user the user to connect with the database.
     * @param password the user password to connect with the database.
     * @param dbName the access database file name.
     * @throws es.ua.db.DatabaseException If any error occurs with the connection with the database.
     */
    public AccessDatabase(String dbName, String user, String password) throws DatabaseException {
        super(DRIVER, getUrl(dbName), user, password, dbName);
    }

    @Override
    public String getDriver() {
        return DRIVER;
    }

    /**
     * Get the connection URL for a specific database.
     * @param dbName The database name.
     * @return A URL with the connection.
     */
    static private String getUrl(String dbName) {
        return "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)}" + 
                ((dbName != null) ? ";DBQ=" + dbName + ';' : ';') + 
                "DriverID=22;READONLY=true}";
    }

    @Override
    public Database newInstance() throws DatabaseException {
        return new AccessDatabase(getName(), getUser(), getPassword());
    }
}
