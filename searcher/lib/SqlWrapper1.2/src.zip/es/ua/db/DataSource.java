/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Iterator;

/**
 * An abstract class which implements common methods for any source of
 * information as a Table or Query. Yoy can obtain of each row of this data
 * source of several ways:
 * <pre>
 * // Open the database connection and obtain a table as data source
 * Database database = new MySQLDatabase(host, user, pass, "my_database");
 * DataSource table = database.getTable("my_table");
 * // ----- Iterate over table rows (mode 1 usign while)
 * while(table.next()) {
 *   int id = (Integer) table.getField("id");
 *   float f = (Float) table.getField("a_float_field");
 *   String s = (String) table.getField("a_string_field");
 *   // Do something
 *   ...
 * }
 * // ----- Iterate over table rows (mode 2 using for)
 * for(table.first(); !table.isEof(); table.next()) { // also while(table.next()) {
 *   int id = (Integer) table.getField("id");
 *   float f = (Float) table.getField("a_float_field");
 *   String s = (String) table.getField("a_string_field");
 *   // Do something
 *   ...
 * }
 * // ----- Iterate over table rows (mode 3 using a iterator)
 * table.first(); // Move to the first table row
 * Iterator<Map> iterator = table.iterator();
 * while(iterator.hasNext()) {
 *   Map map = iterator.next();
 *   int id = (Integer) map.get("id");
 *   float f = (Float) map.ge("a_float_field");
 *   String s = (String) map.get("a_string_field");
 *   // Do something
 *   ...
 * }
 * // ----- Iterate over table rows (mode 4 using JSTL)
 * // In the servlet
 * Database database = new MySQLDatabase(host, user, pass, "my_database");
 * DataSource table = database.getTable("my_table");
 * request.setAttribute("table", table);
 * // In the JSTL page
 * <%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
 * ...
 * &lt;c:forEach var="row" items="${table.iterator}"&gt;
 *     &lt;b&gt;id:&lt;/b&gt;${row['id']}
 *     &lt;b&gt;id:&lt;/b&gt;${row['a_float_field']}
 *     &lt;b&gt;id:&lt;/b&gt;${row['a_string_field']}
 * &lt;/c:forEach&gt;
 * </pre>
 *
 * @see Table
 * @see Query
 * @author Jos&eacute; M. G&oacute;mez;
 */
public abstract class DataSource implements Iterable<Row>, Closeable, AutoCloseable {

    /**
     * The result set which represents this data source.
     */
    protected ResultSet resultSet;
    /**
     * Database which this data source belongs.
     */
    protected Database database;
    /**
     * true if the table is at the end of file.
     */
    private boolean eof;
    /**
     * Number of records of this data source.
     */
    private int size = 0;
    
    public enum BigTextMethod {
        NONE, STRING, CLOB, INPUTSTREAM
    }

    /**
     * Create a new DataSource object from a ResultSet.
     *
     * @param database The database which this data source belongs.
     * @param rs The result set which represent the data source.
     * @throws DatabaseException if a database access error occurs; this
     * exception is called on a closed result set.
     */
    DataSource(Database database, ResultSet rs) throws DatabaseException {
        try {
            resultSet = rs;
            this.database = database;
            // Calculate the number of records
            if (rs.last()) {
                size = rs.getRow();
            }
            // Go to the previous first record and check if the table is empty
            rs.beforeFirst();
            eof = size == 0;
        } catch (SQLException ex) {
            throw new DatabaseException(ex.getMessage(), ex);
        }
    }

    /**
     * Returns the number of fields in this data source.
     *
     * @return the number of fields.
     * @throws DatabaseException if a database access error occurs.
     */
    public int fieldCount() throws DatabaseException {
        try {
            return resultSet.getMetaData().getColumnCount();
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Increase or decrease the table size.
     *
     * @param n Si it is postive, then the size increase, if it is negative
     * descrease
     */
    synchronized protected void changeSize(int n) {
        size += n;
        eof = (size == 0);
    }

    /**
     * Obtain the position of a field in this data source.
     *
     * @param fieldName the field name specified with the SQL AS clause. If the
     * SQL AS clause was not specified, then the label is the name of the
     * column.
     * @return the column index of the given column name.
     * @throws DatabaseException if the data source does not contain a field
     * whith the name fieldName, a database access error occurs or this method
     * is called on a closed data source.
     */
    public int getFieldPosition(String fieldName) throws DatabaseException {
        try {
            return resultSet.findColumn(fieldName);
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Check if the end of file is achieve in this data source.
     *
     * @return true if the data source is at the end, otherwise false.
     * @throws DatabaseException if a database access error occurs, this method
     * is called on a closed data source or if the JDBC driver does not support
     * this method.
     */
    public boolean isEof() throws DatabaseException {
        return eof;
    }

    /**
     * Obtain a value from a data source field.
     *
     * @param fieldName The field name.
     * @return The value of that field.
     * @throws DatabaseException if the data source object does not contain a
     * column labeled columnLabel, a database access error occurs or this method
     * is called on a closed data source.
     */
    public Object getField(String fieldName) throws DatabaseException {
        return getField(fieldName, null, BigTextMethod.NONE);
    }
    
    public Object getField(String fieldName, BigTextMethod method) throws DatabaseException {
        return getField(fieldName, null, method);
    }
    
    /**
     * Obtain a value from a data source field.
     *
     * @param fieldName The field name.
     * @param encoding If the column is a text, you can define an encoding for
     * @return The value of that field.
     * @throws DatabaseException if the data source object does not contain a
     * column labeled columnLabel, a database access error occurs or this method
     * is called on a closed data source.
     */
    public Object getField(String fieldName, String encoding) throws DatabaseException {
        try {
            int column = resultSet.findColumn(fieldName);
            return getField(column, encoding, BigTextMethod.NONE);
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }
    
    public Object getField(String fieldName, String encoding, BigTextMethod method) throws DatabaseException {
        try {
            int column = resultSet.findColumn(fieldName);
            return getField(column, encoding, method);
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }
    
    /**
     * Obtain a value from a data source field.
     *
     * @param column The field number.
     * @return The value of that field.
     * @throws DatabaseException if the data source object does not contain a
     * column labeled columnLabel, a database access error occurs or this method
     * is called on a closed data source.
     */
    public Object getField(int column) throws DatabaseException {
        return getField(column, null, BigTextMethod.NONE);
    }
    
    public Object getField(int column, BigTextMethod method) throws DatabaseException {
        return getField(column, null, method);
    }

    /**
     * Obtain a value from a data source field.
     *
     * @param column The field number.
     * @param encoding If the column is a text, you can define an encoding for
     * extracting the text (if null, then use the system encoding).
     * @return The value of that field.
     * @throws DatabaseException if the data source object does not contain a
     * column labeled columnLabel, a database access error occurs or this method
     * is called on a closed data source.
     */
    public Object getField(int column, String encoding) throws DatabaseException {
        return getField(column, encoding, BigTextMethod.NONE);
    }
    
    public Object getField(int column, String encoding, BigTextMethod method) throws DatabaseException {
        try {
            int type = resultSet.getMetaData().getColumnType(column);
            switch (type) {
                case Types.ARRAY:
                    return resultSet.getArray(column);
                case Types.BIGINT:
                    return resultSet.getBigDecimal(column);
                case Types.TINYINT:
                case Types.BOOLEAN:
                    return resultSet.getBoolean(column);
                case Types.BIT:
                    return resultSet.getBoolean(column);
                case Types.CHAR:
                    return resultSet.getCharacterStream(column);
                case Types.CLOB:
                    switch(method) {
                        case CLOB: return resultSet.getClob(column);
                        case STRING: return resultSet.getString(column);
                        case INPUTSTREAM: return resultSet.getCharacterStream(column);
                    }
                    return resultSet.getClob(column);
                case Types.DATE:
                    return resultSet.getDate(column);
                case Types.DECIMAL:
                case Types.DOUBLE:
                    return resultSet.getDouble(column);
                case Types.REAL:
                case Types.FLOAT:
                    return resultSet.getFloat(column);
                case Types.INTEGER:
                    return resultSet.getInt(column);
                case Types.VARBINARY:
                case Types.LONGVARBINARY:
                case Types.BINARY:
                case Types.BLOB:
                case Types.LONGVARCHAR:
                case Types.VARCHAR:
                    if (encoding == null) {
                        return resultSet.getString(column);
                    } else {
                        return new String(resultSet.getBytes(column), encoding);
                    }
                case Types.NCHAR:
                    return resultSet.getNCharacterStream(column);
                case Types.NCLOB:
                    return resultSet.getNClob(column);
                case Types.LONGNVARCHAR:
                case Types.NVARCHAR:
                    return resultSet.getNString(column);
                case Types.JAVA_OBJECT:
                    return resultSet.getObject(column);
                case Types.REF:
                    return resultSet.getRef(column);
                case Types.SQLXML:
                    return resultSet.getSQLXML(column);
                case Types.SMALLINT:
                    return resultSet.getShort(column);
                case Types.TIME:
                    return resultSet.getTime(column);
                case Types.TIMESTAMP:
                    return resultSet.getTimestamp(column);
//                                case Types.VARBINARY: return resultSet.getBytes(column);
            }
            String typeName = resultSet.getMetaData().getColumnTypeName(column);
            String fieldName = resultSet.getMetaData().getColumnName(column);
            throw new DatabaseException(getErrorMessagePrefix() + "the field of type " + typeName + "(" + type
                    + ") associated to the field class '" + resultSet.getMetaData().getColumnClassName(column)
                    + "' assgined to the field '" + fieldName + "' is not supported yet.");
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        } catch (UnsupportedEncodingException ex) {
            throw new DatabaseException(ex);
        }
    }

    /**
     * Get the designated column's name.
     *
     * @param column the first column is 1, the second is 2, ...
     * @return the field name
     * @throws DatabaseException if a database access error occurs
     */
    public String getFieldName(int column) throws DatabaseException {
        try {
            return resultSet.getMetaData().getColumnName(column);
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * @return Obtain the row number in the data source.
     * @throws DatabaseException if a database access error occurs, this method
     * is called on a closed data source or if the JDBC driver does not support
     * this method.
     */
    public int getRow() throws DatabaseException {
        try {
            return resultSet.getRow();
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Moves the cursor froward one row from its current position. A data source
     * cursor is initially positioned before the first row; the first call to
     * the method next makes the first row the current row; the second call
     * makes the second row the current row, and so on. When a call to the next
     * method returns false, the cursor is positioned after the last row. Any
     * invocation of a data source method which requires a current row will
     * result in a DatabaseException being thrown. If the data source type is
     * TYPE_FORWARD_ONLY, it is vendor specified whether their JDBC driver
     * implementation will return false or throw an DatabaseException on a
     * subsequent call to next.
     *
     * If an input stream is open for the current row, a call to the method next
     * will implicitly close it. A data source object's warning chain is cleared
     * when a new row is read.
     *
     * @return true if the new current row is valid; false if there are no more
     * rows.
     * @throws DatabaseException if a database access error occurs or this
     * method is called on a closed data source.
     */
    public boolean next() throws DatabaseException {
        try {
            eof = !resultSet.next();
            return !eof;
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * This method is used when a database exception is thrown.
     *
     * @return An error message prefix to include in the exception messages.
     */
    abstract String getErrorMessagePrefix();

    /**
     * Moves the cursor to the first row in this data source object.
     *
     * @return true if the cursor is on a valid row; false if there are no rows
     * in the data source
     * @throws DatabaseException if a database access error occurs; this method
     * is called on a closed data source, the data source type is
     * TYPE_FORWARD_ONLY or if the JDBC driver does not support this method
     */
    public boolean first() throws DatabaseException {
        try {
            eof = !resultSet.first();
            return !eof;
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Moves the cursor to the last row in this data source object.
     *
     * @return true if the cursor is on a valid row; false if there are no rows
     * in the data source.
     *
     * @throws DatabaseException if a database access error occurs; this method
     * is called on a closed data source, the data source type is
     * TYPE_FORWARD_ONLY or if the JDBC driver does not support this method
     */
    public boolean last() throws DatabaseException {
        try {
            eof = !resultSet.last();
            return !eof;
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Moves the cursor to the previous row in this data source object. When a
     * call to the previous method returns false, the cursor is positioned
     * before the first row. Any invocation of a data source method which
     * requires a current row will result in a DatabaseException being thrown.
     * If an input stream is open for the current row, a call to the method
     * previous will implicitly close it. A data source's warning change is
     * cleared when a new row is read.
     *
     * @return true if the cursor is now positioned on a valid row; false if the
     * cursor is positioned before the first row
     * @throws DatabaseException if a database access error occurs; this method
     * is called on a closed data source, the data source type is
     * TYPE_FORWARD_ONLY or if the JDBC driver does not support this method.
     */
    public boolean previous() throws DatabaseException {
        try {
            eof = !resultSet.previous();
            return !eof;
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Moves the cursor to the given row number in this data source. If the row
     * number is positive, the cursor moves to the given row number with respect
     * to the beginning of the data source. The first row is row 1, the second
     * is row 2, and so on. If the given row number is negative, the cursor
     * moves to an absolute row position with respect to the end of the data
     * source. For example, calling the method move(-1) positions the cursor on
     * the last row; calling the method move(-2) moves the cursor to the
     * next-to-last row, and so on. An attempt to position the cursor beyond the
     * first/last row in the data source leaves the cursor before the first row
     * or after the last row.
     * <p>
     * Note: Calling move(1) is the same as calling first(). Calling move(-1) is
     * the same as calling last().</p>
     *
     * @param row the number of the row to which the cursor should move. A
     * positive number indicates the row number counting from the beginning of
     * the data source; a negative number indicates the row number counting from
     * the end of the data source
     * @return true if the cursor is moved to a position in this data source;
     * false if the cursor is before the first row or after the last row
     * @throws DatabaseException if a database access error occurs; this method
     * is called on a closed data source, the data source type is
     * TYPE_FORWARD_ONLY or if the JDBC driver does not support this method.
     */
    public boolean move(int row) throws DatabaseException {
        try {
            eof = !resultSet.absolute(row);
            return !eof;
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Retrieves the number of rows of this data source.
     *
     * @return the current fetch size for this data source
     */
    public int size() {
        return size;
    }
    
    /**
     * Retrieves the number of rows of this data source.
     *
     * @return the current fetch size for this data source
     */
    public int getSize() {
        return size();
    }

    /**
     * Releases this data source and JDBC resources immediately instead of
     * waiting for this to happen when it is automatically closed. The closing
     * of a data source does not close the Blob, Clob or NClob objects created
     * by the data source. Blob, Clob or NClob objects remain valid for at least
     * the duration of the transaction in which they are creataed, unless their
     * free method is invoked. When a data source is closed, any
     * ResultSetMetaData instances that were created by calling the getMetaData
     * method remain accessible.
     *
     * <p>
     * <b>Note:</p> A data source is automatically closed by the Statement
     * object that generated it when that Statement object is closed,
     * re-executed, or is used to retrieve the next result from a sequence of
     * multiple results. Calling the method close on a data source that is
     * already closed is a no-op.</p>
     *
     * @throws DatabaseException if a database access error occurs.
     */
    public void close() throws DatabaseException {
        try {
            resultSet.getStatement().close();
            resultSet.close();
            database.removeOpenedDataSource(this);
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Check if this data source is empty.
     *
     * @return true if the data source is empty; false otherwise.
     */
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public Iterator<Row> iterator() {
        return new DataIterator(this);
    }

    /**
     * Returns an iterator over a set of elements of type Map.
     *
     * @return an Iterator.
     */
    public Iterator<Row> getIterator() {
        return iterator();
    }

    /**
     * A iterator over each row of a data source (Table, Query...). Each element
     * of this iterator returns a map which relates each field name with its
     * value.
     */
    private class DataIterator implements Iterator<Row> {

        /**
         * The data source to build the iterator.
         */
        final private DataSource source;

        /**
         * Construct a data iterator from a data source.
         *
         * @param source the data source.
         */
        public DataIterator(DataSource source) {
            this.source = source;
        }

        @Override
        public boolean hasNext() {
            try {
                return source.getRow() < source.size();
            } catch (DatabaseException ex) {
                throw new RuntimeException(ex);
            }
        }

        @Override
        public Row next() {
            try {
                if (source.next() == false) {
                    return null;
                }
                return new Row(source);
            } catch (DatabaseException ex) {
                throw new RuntimeException(ex);
            }
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("This iterator doesn't allow modification operations.");
        }
    }
}
