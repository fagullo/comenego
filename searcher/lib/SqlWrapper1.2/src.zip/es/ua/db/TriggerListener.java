/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import es.ua.db.Trigger.ActionTime;
import java.util.Iterator;

/**
 * A database trigger listener.
 * @author Jos&eacute; M. G&oacute;mez;
 */
public interface TriggerListener {
    /**
     * This event is thrown when an insert operation is made in the table.
     * @param addRows The inserted rows.
     * @param table the table which the change is done.
     * @param time if this event is thrown BEFORE or AFTER the change is done.
     * @throws Throwable if any exception occurs while we deal with the event. 
     * In the case that a exception occurs then the event 
     * {@link #errorEvent(es.ua.db.DatabaseException, es.ua.db.Table, es.ua.db.Trigger.ActionTime) errorEvent}
     * is called.
     */
    public void insertEvent(Iterator<Row> addRows, Table table, ActionTime time) throws Throwable;
    
    /**
     * This event is thrown when an update operation is made in the table.
     * @param oldRows The old values of the modified rows.
     * @param newRows The new values of the modified rows.
     * @param table the table which the change is done.
     * @param time if this event is thrown BEFORE or AFTER the change is done.
     * @throws Throwable if any exception occurs while we deal with the event. 
     * In the case that a exception occurs then the event 
     * {@link #errorEvent(es.ua.db.DatabaseException, es.ua.db.Table, es.ua.db.Trigger.ActionTime) errorEvent}
     * is called.
     */
    public void updateEvent(Iterator<Row> oldRows, Iterator<Row> newRows, Table table, ActionTime time) throws Throwable;
    
    /**
     * This event is thrown when a delete operation is made in the table.
     * @param deletedRows The deleted rows.
     * @param table the table which the change is done.
     * @param time if this event is thrown BEFORE or AFTER the change is done.
     * @throws Throwable if any exception occurs while we deal with the event. 
     * In the case that a exception occurs then the event 
     * {@link #errorEvent(es.ua.db.DatabaseException, es.ua.db.Table, es.ua.db.Trigger.ActionTime) errorEvent}
     * is called.
     */
    public void deleteEvent(Iterator<Row> deletedRows, Table table, ActionTime time) throws Throwable;
    
    /**
     * This event is thrown if any of the rest of events has throw a database exception
     * @param ex the thrown exception.
     * @param table the table which the trigger was watching
     * @param time if this event is thrown BEFORE or AFTER the change is done.
     * @throws Throwable if you want to stop and close properly the trigger due to the error ex
     * then you only need throw any exception.
     */
    public void errorEvent(Throwable ex, Table table, ActionTime time) throws Throwable;
}
