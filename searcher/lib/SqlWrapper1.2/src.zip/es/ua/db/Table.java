/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

import static es.ua.db.Table.TableStates.INSERT;
import static es.ua.db.Table.TableStates.NORMAL;
import static es.ua.db.Table.TableStates.UPDATE;
import java.sql.ResultSet;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Table which represent a database table. With a instance of this class you can
 * iterate over each table row, move to a specific row, modify some fields of a
 * row, add or remove rows and obtain the number of table rows.
 * <pre>
 * // Open the database connection and obtain the table
 * Database database = new MySQLDatabase(host, user, pass, "my_database");
 * Table table = database.getTable("my_table");
 * // Add a row
 * table.append();
 * table.setField("id",1);
 * table.setField("a_float_field", 2.0f);
 * table.setField("a_string_field", "a value");
 * table.commit();
 * // Move to a specific row
 * table.move(5);
 * // Remove a row
 * table.delete();
 * // Iterate over table rows
 * for(table.first(); !table.isEof(); table.next()) { // also while(table.next()) {
 *   int id = (Integer) table.getField("id");
 *   float f = (Float) table.getField("a_float_field");
 *   String s = (String) table.getField("a_string_field");
 *   // Do something
 *   ...
 * }
 * // Edit a row table
 * table.move(5);
 * table.edit();
 * table.setField("a_float_field", 4.0f);
 * table.commit();
 * // Obtain the table size
 * System.out.println(table.size());
 * // Remove all rows
 * table.deleteAllrows();
 * </pre>
 * <p>
 * For more examples to iterate over table rows you can see DataSource
 * javadoc.</p>
 *
 * @see DataSource
 * @author Jos&eacute; M. G&oacute;mez;
 */
public class Table extends DataSource {

    /**
     * @return the table name.
     */
    public String getName() {
        return name;
    }

    /**
     * The table states.
     */
    static public enum TableStates {

        NORMAL, INSERT, UPDATE
    };

    /**
     * Table mode which allows to move among the table registers.
     */
//	final public static short NORMAL = 0;
//	/** Table mode which insert a register at the end of the table. */
//	final public static short INSERT = 1;
//	/** Table mode which can modify a register. */
//	final public static short UPDATE = 2;
    /**
     * The ordering ways to sort the table.
     */
    static public enum TableOrdering {

        ASCENDENT, DESCENDENT
    };
    /**
     * If the table order is ascendent.
     */
//	final public static short ASCENDENT = 1;
    /**
     * If the table order is ascendent.
     */
//	final public static short DESCENDENT = 2;
    /**
     * The table mode (NORMAL, INSERT or UPDATE).
     */
    private TableStates mode;
    /**
     * The table name.
     */
    private final String name;
    /**
     * Filter applied to the table.
     */
    private final String filter;

    /**
     * Build a table object.
     *
     * @param database The database which this table belongs.
     * @param tableName the name of the table.
     * @param rs the result set which this table represents.
     * @throws DatabaseException if a database access error occurs; this
     * exception is called on a closed result set.
     */
    Table(Database database, String tableName, ResultSet rs) throws DatabaseException {
        super(database, rs);
        this.mode = NORMAL;
        name = tableName;
        filter = null;
    }

    /**
     * Build a table object with a filter.
     *
     * @param database The database which this table belongs.
     * @param filter table filter.
     * @param tableName the name of the table.
     * @param rs the result set which this table represents.
     * @throws DatabaseException if a database access error occurs; this
     * exception is called on a closed result set.
     */
    Table(Database database, String tableName, ResultSet rs, String filter) throws DatabaseException {
        super(database, rs);
        this.mode = NORMAL;
        name = tableName;
        this.filter = filter;
    }

    /**
     * Add a blank register to this table. After this method is called, in order
     * to fill the fields of this register, it is necessary to call the methods
     * setField() and, finally, to store the information to commit() or to
     * cancel the changes to rollback().
     *
     * @throws DatabaseException If this table is already in mode edit or
     * append.
     * @see #setField(java.lang.String, java.lang.Object)
     * @see #commit()
     * @see #rollback()
     */
    public void append() throws DatabaseException {
        try {
            if (mode != NORMAL) {
                throw new DatabaseException(getErrorMessagePrefix() + " must to finish the previous table "
                        + (mode == INSERT ? "insertion" : "edition") + " before to add other register.");
            }
            resultSet.moveToInsertRow();
            mode = INSERT;
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Edit the current register to this table. After this method is called, in
     * order to fill the fields of this register, it is necessary to call the
     * methods setField() and, finally, to store the information to commit() or
     * to cancel the changes to rollback().
     *
     * @throws DatabaseException If this table is already in mode edit or
     * append.
     * @see #setField(java.lang.String, java.lang.Object)
     * @see #setField(int, java.lang.Object)
     * @see #commit()
     * @see #rollback()
     */
    public void edit() throws DatabaseException {
        try {
            if (mode != NORMAL) {
                throw new DatabaseException(getErrorMessagePrefix() + " the table is already in mode "
                        + (mode == INSERT ? "insertion" : "edition") + ", please finalize it before to modify a register.");
            }
            resultSet.updateRow();
            mode = UPDATE;
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Add a value to a field of this table.
     *
     * @param fieldName The field name.
     * @param fieldValue The field value.
     * @throws DatabaseException if the table is not in insert or edit mode, a
     * database access error occurs, the field type is not supported or the
     * table is closed.
     * @see #setField(int, java.lang.Object)
     * @see #append()
     * @see #edit()
     * @see #commit()
     * @see #rollback()
     */
    public void setField(String fieldName, Object fieldValue) throws DatabaseException {
        try {
            int column = resultSet.findColumn(fieldName);
            setField(column, fieldValue);
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Add a value to a field of this table.
     *
     * @param column The field number.
     * @param fieldValue The field value.
     * @throws DatabaseException if the table is not in insert or edit mode, a
     * database access error occurs, the field type is not supported or the
     * table is closed.
     * @see #setField(java.lang.String, java.lang.Object)
     * @see #append()
     * @see #edit()
     * @see #commit()
     * @see #rollback()
     */
    public void setField(int column, Object fieldValue) throws DatabaseException {
        try {
            if (mode == NORMAL) {
                throw new DatabaseException(getErrorMessagePrefix() + " the table is not in insert or edit mode.");
            }
            int type = resultSet.getMetaData().getColumnType(column);
            switch (type) {
                case Types.ARRAY:
                    resultSet.updateArray(column, (Array) fieldValue);
                    break;
                case Types.DECIMAL:
                case Types.BIGINT:
                    resultSet.updateBigDecimal(column, new BigDecimal((String) fieldValue.toString()));
                    break;
                case Types.LONGVARBINARY:
                case Types.BINARY:
                    resultSet.updateBytes(column, (byte[]) fieldValue);
                    break;
//                    resultSet.updateBinaryStream(column, (InputStream)fieldValue); break;
                case Types.BLOB:
                    resultSet.updateBytes(column, (byte[]) fieldValue);
                    break;
//                    resultSet.updateBlob(column, (Blob)fieldValue); break;
                case Types.TINYINT:
                case Types.BIT:
                case Types.BOOLEAN:
                    resultSet.updateBoolean(column, (Boolean) fieldValue);
                    break;
                case Types.CHAR:
                    resultSet.updateCharacterStream(column, (Reader) fieldValue);
                    break;
                case Types.CLOB:
                    resultSet.updateClob(column, (Clob) fieldValue);
                    break;
                case Types.DATE:
                    if(fieldValue instanceof Date) {
                        resultSet.updateDate(column, new java.sql.Date(((Date) fieldValue).getTime()));
                    } if(fieldValue instanceof Calendar) {
                        resultSet.updateDate(column, new java.sql.Date(((Calendar) fieldValue).getTimeInMillis()));
                    } else {
                        resultSet.updateDate(column, (java.sql.Date) fieldValue);
                    }
                    break;
                case Types.DOUBLE:
                    resultSet.updateDouble(column, (Double) fieldValue);
                    break;
                case Types.FLOAT:
                    resultSet.updateFloat(column, (Float) fieldValue);
                    break;
                case Types.INTEGER:
                    resultSet.updateLong(column, (Long) fieldValue);
                    break;
                case Types.LONGVARCHAR:
                case Types.VARCHAR:
                    resultSet.updateString(column, (String) fieldValue);
                    break;
                case Types.NCHAR:
                    resultSet.updateNCharacterStream(column, (Reader) fieldValue);
                    break;
                case Types.NCLOB:
                    resultSet.updateNClob(column, (NClob) fieldValue);
                    break;
                case Types.LONGNVARCHAR:
                case Types.NVARCHAR:
                    resultSet.updateNString(column, (String) fieldValue);
                    break;
                case Types.JAVA_OBJECT:
                    resultSet.updateObject(column, fieldValue);
                    break;
                case Types.REF:
                    resultSet.updateRef(column, (Ref) fieldValue);
                    break;
                case Types.SQLXML:
                    resultSet.updateSQLXML(column, (SQLXML) fieldValue);
                    break;
                case Types.SMALLINT:
                    resultSet.updateShort(column, (Short) fieldValue);
                    break;
                case Types.TIME:
                    resultSet.updateTime(column, (Time) fieldValue);
                    break;
                case Types.TIMESTAMP:
                    resultSet.updateTimestamp(column, (Timestamp) fieldValue);
                    break;
                default:
                    String typeName = resultSet.getMetaData().getColumnTypeName(column);
                    String fieldName = resultSet.getMetaData().getColumnName(column);
                    throw new DatabaseException(getErrorMessagePrefix() + "the field of type " + typeName + "(" + type
                            + ") associated to the field class '" + resultSet.getMetaData().getColumnClassName(column)
                            + "' assgined to the field '" + fieldName + "' is not supported yet.");
            }
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }
    
    /**
     * Return the type of a field.
     * @param fieldName The field name.
     * @return a string which represents the type of a field.
     * @throws DatabaseException if the ResultSet object does not contain a column 
     * labeled columnLabel, a database access error occurs or this method is called on a closed result set.
     */
    public String getColumnTypeName(String fieldName) throws DatabaseException {
        try {
            return getColumnTypeName(resultSet.findColumn(fieldName));
        } catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }
    
    /* Return the type of a field.
     * @param column the column number.
     * @return a string which represents the type of a field.
     * @throws DatabaseException if the ResultSet object does not contain a column 
     * labeled columnLabel, a database access error occurs or this method is called on a closed result set.
     */
    public String getColumnTypeName(int column) throws DatabaseException {
        try {
            return resultSet.getMetaData().getColumnTypeName(column);
        } catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }
    
    public int getColumnSize(int column) throws DatabaseException {
        try {
            return resultSet.getMetaData().getColumnDisplaySize(column);
        } catch (SQLException ex) {
            throw new DatabaseException(ex);
        }
    }

    /**
     * @return the table state.
     * @see TableStates#NORMAL
     * @see TableStates#INSERT
     * @see TableStates#UPDATE
     */
    public TableStates getState() {
        return mode;
    }

    /**
     * Save the changes in the table.
     *
     * @throws DatabaseException if the table is not in insert or edit mode,
     * database access error occurs, this method is called on a closed table or
     * if the JDBC driver does not support this method.
     */
    public void commit() throws DatabaseException {
        try {
            switch (mode) {
                case UPDATE:
                    mode = NORMAL;
                    resultSet.updateRow();
                    break;
                case INSERT:
                    mode = NORMAL;
                    resultSet.insertRow();
                    changeSize(1);
                    break;
                default:
                    throw new DatabaseException(getErrorMessagePrefix() + "not on insert or edit mode.");
            }
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Cancel the changes in the table.
     *
     * @throws DatabaseException if the table is not in insert or edit mode, a
     * database access error occurs, this method is called on a closed table or
     * if the JDBC driver does not support this method.
     */
    public void rollback() throws DatabaseException {
        try {
            if (mode == NORMAL) {
                throw new DatabaseException(getErrorMessagePrefix() + "not on insert or edit mode.");
            }
            mode = NORMAL;
            resultSet.cancelRowUpdates();
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    /**
     * Delete all rows from this table.
     *
     * @throws DatabaseException if a database access error occurs; the result
     * set concurrency is CONCUR_READ_ONLY; this method is called on a closed
     * result set or if this method is called when the table is on insert or
     * edit mode, or if the JDBC driver does not support this method.
     */
    public void deleteAll() throws DatabaseException {
        if (mode != NORMAL) {
            throw new DatabaseException(getErrorMessagePrefix() + " must to finish the previous table "
                    + (mode == INSERT ? "insertion" : "edition") + " before to remove the table content.");
        }
        database.deleteAllRows(getName());
        changeSize(-size());
    }

    /**
     * Delete all rows from this table which fulfills the condition.
     *
     * @param condition the row condition to fulfill in order to be removed.
     * @return if the sql operation was executed successfully, false otherwise.
     * @throws DatabaseException if a database access error occurs; the result
     * set concurrency is CONCUR_READ_ONLY; this method is called on a closed
     * result set or if this method is called when the table is on insert or
     * edit mode, or if the JDBC driver does not support this method.
     */
    public boolean deleteAll(String condition) throws DatabaseException {
        if (mode != NORMAL) {
            throw new DatabaseException(getErrorMessagePrefix() + " must to finish the previous table "
                    + (mode == INSERT ? "insertion" : "edition") + " before to remove the table content.");
        }
        boolean result = database.deleteRows(getName(), condition);
        changeSize(-size());
        return result;
    }

    /**
     * Deletes the current row from this ResultSet objeRct and from the
     * underlying database. This method cannot be called when the cursor is on
     * the insert row.
     *
     * @throws DatabaseException if a database access error occurs; the result
     * set concurrency is CONCUR_READ_ONLY; this method is called on a closed
     * result set or if this method is called when the table is on insert or
     * edit mode, or if the JDBC driver does not support this method.
     */
    public void delete() throws DatabaseException {
        try {
            if (mode != NORMAL) {
                throw new DatabaseException(getErrorMessagePrefix() + " must to finish the previous table "
                        + (mode == INSERT ? "insertion" : "edition") + " before to remove a register.");
            }
            resultSet.deleteRow();
            changeSize(-1);
        } catch (SQLException ex) {
            throw new DatabaseException(getErrorMessagePrefix() + ex.getMessage(), ex);
        }
    }

    @Override
    String getErrorMessagePrefix() {
        return "An error has ocurred in the table '" + getName() + "': ";
    }

    /**
     * Search one or more register which fulfils that condition.
     *
     * @param condition The condition to fulfill.
     * @return A modificable table with only the registers which fulfills that
     * condition.
     * @throws DatabaseException if a database access error occurs or this
     * method is called on a closed table.
     */
    public Table search(String condition) throws DatabaseException {
        if (filter == null) {
            return database.getTable(getName(), condition);
        }
        return database.getTable(getName(), filter + " AND " + condition);
    }

    /**
     * Search one or more register which fulfils that condition.
     *
     * @param condition The condition.
     * @param sortedBy The name of fields, split by commas which the table will
     * be ordered.
     * @param orderMode The table order mode (acendent or descedent).
     * @return A modificable table with only the registers which fulfils that
     * condition.
     * @throws DatabaseException if a database access error occurs or this
     * method is called on a closed table.
     * @see TableOrdering#ASCENDENT
     * @see TableOrdering#DESCENDENT
     */
    public Table search(String condition, String sortedBy, TableOrdering orderMode) throws DatabaseException {
        if (filter == null) {
            return database.getTable(getName(), condition, sortedBy, orderMode);
        }
        return database.getTable(getName(), filter + " AND " + condition, sortedBy, orderMode);
    }
}
