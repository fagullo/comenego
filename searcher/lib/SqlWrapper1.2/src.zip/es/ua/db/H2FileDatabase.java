/* Copyright © 2008 GPLSI
 *
 * This java class is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * This java class is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.</p>
 * You should have received a copy of the GNU General Public License
 * along with this java class.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.ua.db;

/** Simple wrapper to work with H2 databases.
 *
 * @author Javi Fern&aacute;ndez
 */
public class H2FileDatabase extends Database {
    
    /** The jdbc driver for H2. */
    private final static String DRIVER = "org.h2.Driver";
    /** The protocol for H2. */
    private final static String PROTOCOL = "jdbc:h2:";
    /** The current database file name. */
    private final String fileName;

    /**
     * Creates a new connection to the database.
     * @param fileName Database file name.
     * @throws DatabaseException 
     */
    public H2FileDatabase(String fileName) throws DatabaseException {
        super(DRIVER, PROTOCOL + fileName, "sa", "sa", "");
        this.fileName = fileName;
    }

    /**
     * Creates a new connection to the database.
     * @param fileName Database file name.
     * @param databaseName Database name.
     * @throws DatabaseException 
     */
    public H2FileDatabase(String fileName, String databaseName) throws DatabaseException {
        super(DRIVER, PROTOCOL + fileName, "sa", "sa", databaseName);
        this.fileName = fileName;
    }

    @Override
    public String getDriver() {
        return DRIVER;
    }

    @Override
    public Database newInstance() throws DatabaseException {
        return new H2FileDatabase(fileName);
    }
}
